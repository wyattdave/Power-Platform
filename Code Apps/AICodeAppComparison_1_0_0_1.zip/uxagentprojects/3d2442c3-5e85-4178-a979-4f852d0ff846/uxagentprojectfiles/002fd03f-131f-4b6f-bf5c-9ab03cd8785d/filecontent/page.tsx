import React, { useState, useEffect, useMemo } from "react";
import {
    Text,
    Divider,
    Avatar,
    DataGrid,
    DataGridHeader,
    DataGridBody,
    DataGridRow,
    DataGridCell,
    DataGridHeaderCell,
    TableCellLayout,
    createTableColumn
} from "@fluentui/react-components";
import { MailRegular, PersonRegular, ClockRegular } from "@fluentui/react-icons";

// Profile Section
function ProfileSection({
    profile,
    t,
}: {
    profile: {
        name: string;
        email: string;
        phone?: string;
        role?: string;
        imageUrl?: string;
    };
    t: (key: string) => string;
}) {
    return (
        <section
            style={{
                display: "flex",
                alignItems: "center",
                gap: "24px",
                padding: "24px 0",
                boxSizing: "border-box",
            }}
            aria-label={t("profileTitle")}
        >
            <Avatar
                name={profile.name}
                src={profile.imageUrl}
                size={96}
                style={{
                    borderRadius: "50%",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
                    maxWidth: "96px",
                    height: "96px",
                    objectFit: "cover",
                }}
                alt={profile.name}
            />
            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                <Text as="h1" size={700} weight="semibold" block>
                    {profile.name}
                </Text>
                {profile.role && (
                    <Text size={400} block>
                        <PersonRegular fontSize="1.2em" style={{ marginInlineEnd: 8 }} />
                        {t("role")}: {profile.role}
                    </Text>
                )}
                <Text size={400} block>
                    <MailRegular fontSize="1.2em" style={{ marginInlineEnd: 8 }} />
                    {t("email")}: {profile.email}
                </Text>
                {profile.phone && (
                    <Text size={400} block>
                        <ClockRegular fontSize="1.2em" style={{ marginInlineEnd: 8 }} />
                        {t("phone")}: {profile.phone}
                    </Text>
                )}
            </div>
        </section>
    );
}

// Emails Section
function EmailsSection({
    emails,
    t,
    formatDate,
    formatTime,
}: {
    emails: {
        id: string;
        from: string;
        subject: string;
        date: Date;
        preview: string;
    }[];
    t: (key: string) => string;
    formatDate: (date: Date) => string;
    formatTime: (date: Date) => string;
}) {
    const columns = [
        createTableColumn({
            columnId: "from",
            renderHeaderCell: () => (
                <Text weight="bold" size={400} style={{ padding: 8 }}>
                    {t("from")}
                </Text>
            ),
            renderCell: (item) => (
                <TableCellLayout>
                    <MailRegular fontSize="1em" style={{ marginInlineEnd: 4 }} />
                    {item.from}
                </TableCellLayout>
            ),
        }),
        createTableColumn({
            columnId: "subject",
            renderHeaderCell: () => (
                <Text weight="bold" size={400} style={{ padding: 8 }}>
                    {t("subject")}
                </Text>
            ),
            renderCell: (item) => <TableCellLayout>{item.subject}</TableCellLayout>,
        }),
        createTableColumn({
            columnId: "date",
            renderHeaderCell: () => (
                <Text weight="bold" size={400} style={{ padding: 8 }}>
                    {t("date")}
                </Text>
            ),
            renderCell: (item) => (
                <TableCellLayout>
                    {formatDate(item.date)} {formatTime(item.date)}
                </TableCellLayout>
            ),
        }),
        createTableColumn({
            columnId: "preview",
            renderHeaderCell: () => (
                <Text weight="bold" size={400} style={{ padding: 8 }}>
                    {t("preview")}
                </Text>
            ),
            renderCell: (item) => (
                <TableCellLayout>
                    <Text size={300} style={{ color: "#666" }}>
                        {item.preview}
                    </Text>
                </TableCellLayout>
            ),
        }),
    ];

    return (
        <section
            style={{
                margin: "24px 0",
                boxSizing: "border-box",
                display: "flex",
                flexDirection: "column",
            }}
            aria-label={t("emailsTitle")}
        >
            <Text as="h2" size={600} weight="semibold" block style={{ marginBottom: 12 }}>
                {t("emailsTitle")}
            </Text>
            <div style={{ maxHeight: "320px", overflow: "auto", borderRadius: "8px", boxShadow: "0 1px 4px rgba(0,0,0,0.04)" }}>
                {emails.length === 0 ? (
                    <Text size={400} style={{ padding: 16 }}>{t("noEmails")}</Text>
                ) : (
                    <DataGrid
                        items={emails}
                        columns={columns}
                        sortable
                        selectionMode="none"
                        getRowId={(i) => i.id}
                        focusMode="composite"
                        style={{ minWidth: 600 }}
                    >
                        <DataGridHeader>
                            <DataGridRow>
                                {({ renderHeaderCell }) => (
                                    <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>
                                )}
                            </DataGridRow>
                        </DataGridHeader>
                        <DataGridBody<typeof emails[0]>
                            >
                            {({ item, rowId }) => (
                                <DataGridRow key={rowId}>
                                    {({ renderCell }) => <DataGridCell>{renderCell(item)}</DataGridCell>}
                                </DataGridRow>
                            )}
                        </DataGridBody>
                    </DataGrid>
                )}
            </div>
        </section>
    );
}

// Meetings Section
function MeetingsSection({
    meetings,
    t,
    formatDate,
    formatTime,
}: {
    meetings: { id: string; title: string; datetime: Date }[];
    t: (key: string) => string;
    formatDate: (date: Date) => string;
    formatTime: (date: Date) => string;
}) {
    return (
        <section
            style={{
                margin: "24px 0",
                boxSizing: "border-box",
                display: "flex",
                flexDirection: "column",
            }}
            aria-label={t("meetingsTitle")}
        >
            <Text as="h2" size={600} weight="semibold" block style={{ marginBottom: 12 }}>
                {t("meetingsTitle")}
            </Text>
            <div style={{ maxHeight: "240px", overflow: "auto", borderRadius: "8px", boxShadow: "0 1px 4px rgba(0,0,0,0.04)" }}>
                {meetings.length === 0 ? (
                    <Text size={400} style={{ padding: 16 }}>{t("noMeetings")}</Text>
                ) : (
                    <DataGrid
                        items={meetings}
                        columns={[
                            createTableColumn({
                                columnId: "datetime",
                                renderHeaderCell: () => (
                                    <Text weight="bold" size={400} style={{ padding: 8 }}>
                                        {t("meetingTime")}
                                    </Text>
                                ),
                                renderCell: (item) => (
                                    <TableCellLayout>
                                        {formatDate(item.datetime)} {formatTime(item.datetime)}
                                    </TableCellLayout>
                                ),
                            }),
                            createTableColumn({
                                columnId: "title",
                                renderHeaderCell: () => (
                                    <Text weight="bold" size={400} style={{ padding: 8 }}>
                                        {t("meetingTitle")}
                                    </Text>
                                ),
                                renderCell: (item) => (
                                    <TableCellLayout>
                                        <ClockRegular fontSize="1em" style={{ marginInlineEnd: 4 }} />
                                        {item.title}
                                    </TableCellLayout>
                                ),
                            }),
                        ]}
                        selectionMode="none"
                        getRowId={(i) => i.id}
                        focusMode="composite"
                        style={{ minWidth: 400 }}
                    >
                        <DataGridHeader>
                            <DataGridRow>
                                {({ renderHeaderCell }) => (
                                    <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>
                                )}
                            </DataGridRow>
                        </DataGridHeader>
                        <DataGridBody<typeof meetings[0]>
                            >
                            {({ item, rowId }) => (
                                <DataGridRow key={rowId}>
                                    {({ renderCell }) => <DataGridCell>{renderCell(item)}</DataGridCell>}
                                </DataGridRow>
                            )}
                        </DataGridBody>
                    </DataGrid>
                )}
            </div>
        </section>
    );
}

// Main Component
const GeneratedComponent = () => {
    // Localization setup
    const langMap: Record<number, { code: string; name: string; isRtl: boolean }> = {
        1033: { code: "en-US", name: "English (United States)", isRtl: false },
    };
    const language = useMemo(() => {
        const uiLanguageId =
            (typeof Xrm !== "undefined" &&
                Xrm.Utility?.getGlobalContext()?.userSettings?.languageId) || 1033;
        return langMap[uiLanguageId]?.code || "en-US";
    }, []);
    const isRTL = useMemo(() => {
        const uiLanguageId =
            (typeof Xrm !== "undefined" &&
                Xrm.Utility?.getGlobalContext()?.userSettings?.languageId) || 1033;
        return langMap[uiLanguageId]?.isRtl || false;
    }, []);
    const translations: Record<string, Record<string, string>> = {
        "en-US": {
            profileTitle: "Profile",
            name: "Name",
            email: "Email",
            phone: "Phone",
            role: "Role",
            emailsTitle: "Recent Emails",
            from: "From",
            subject: "Subject",
            date: "Date",
            preview: "Preview",
            meetingsTitle: "Meetings This Week",
            meetingTitle: "Title",
            meetingTime: "Time",
            noMeetings: "No meetings scheduled this week.",
            noEmails: "No emails found.",
        },
    };
    const t = (key: string): string =>
        translations[language]?.[key] || translations["en-US"]?.[key] || key;

    // User settings for formatting (mocked, since no dataApi)
    const [userSettings, setUserSettings] = useState<any>(null);
    useEffect(() => {
        setUserSettings({
            dateformatstring: "MM/dd/yyyy",
            dateseparator: "/",
            decimalsymbol: ".",
            numberseparator: ",",
            currencysymbol: "$",
        });
    }, []);

    // Formatting helpers
    const formatDate = (date: Date): string => {
        if (!userSettings) return date.toLocaleDateString(language);
        const sep = userSettings.dateseparator || "/";
        const fmt = (userSettings.dateformatstring || "MM/dd/yyyy")
            .replace("yyyy", date.getFullYear().toString())
            .replace("MM", String(date.getMonth() + 1).padStart(2, "0"))
            .replace("dd", String(date.getDate()).padStart(2, "0"))
            .replace("/", sep)
            .replace("/", sep);
        return fmt;
    };
    const formatTime = (date: Date): string => {
        return date.toLocaleTimeString(language, { hour: "2-digit", minute: "2-digit" });
    };

    // Get logged-in user details from Xrm.Utility.getGlobalContext().userSettings
    const userSettingsObj =
        typeof Xrm !== "undefined" && Xrm.Utility?.getGlobalContext()?.userSettings
            ? Xrm.Utility.getGlobalContext().userSettings
            : null;

    // Build profile object from userSettings
    const profile = {
        name: userSettingsObj?.userName || "User",
        email: userSettingsObj?.userEmail || "",
        phone: "", // Not available in userSettings
        role: "", // Not available in userSettings
        imageUrl: undefined, // No image available, Avatar will use initials
    };

    // Mock emails data
    const emails = [
        {
            id: "1",
            from: "Sarah Lee",
            subject: "Quarterly Report",
            date: new Date(Date.now() - 3600 * 1000 * 2),
            preview: "Please find attached the Q1 report for your review.",
        },
        {
            id: "2",
            from: "IT Support",
            subject: "Password Reset",
            date: new Date(Date.now() - 3600 * 1000 * 5),
            preview: "Your password has been successfully reset.",
        },
        {
            id: "3",
            from: "John Smith",
            subject: "Meeting Follow-up",
            date: new Date(Date.now() - 3600 * 1000 * 8),
            preview: "Thanks for your input in today's meeting.",
        },
        {
            id: "4",
            from: "Marketing Team",
            subject: "Campaign Launch",
            date: new Date(Date.now() - 3600 * 1000 * 12),
            preview: "Our new campaign launches tomorrow.",
        },
        {
            id: "5",
            from: "HR",
            subject: "Benefits Update",
            date: new Date(Date.now() - 3600 * 1000 * 16),
            preview: "Review the updated benefits package.",
        },
        {
            id: "6",
            from: "Finance",
            subject: "Invoice Received",
            date: new Date(Date.now() - 3600 * 1000 * 20),
            preview: "We've received your invoice for processing.",
        },
        {
            id: "7",
            from: "Jane Doe",
            subject: "Lunch Invitation",
            date: new Date(Date.now() - 3600 * 1000 * 24),
            preview: "Would you like to join for lunch tomorrow?",
        },
        {
            id: "8",
            from: "Project Team",
            subject: "Project Update",
            date: new Date(Date.now() - 3600 * 1000 * 28),
            preview: "Project is on track for completion.",
        },
        {
            id: "9",
            from: "Admin",
            subject: "System Maintenance",
            date: new Date(Date.now() - 3600 * 1000 * 32),
            preview: "Scheduled maintenance will occur this weekend.",
        },
        {
            id: "10",
            from: "Legal",
            subject: "Contract Review",
            date: new Date(Date.now() - 3600 * 1000 * 36),
            preview: "Please review the attached contract.",
        },
    ];

    // Mock meetings data (only meetings this week)
    const getWeekMeetings = () => {
        const now = new Date();
        const startOfWeek = new Date(now);
        startOfWeek.setDate(now.getDate() - now.getDay());
        startOfWeek.setHours(0, 0, 0, 0);
        const endOfWeek = new Date(startOfWeek);
        endOfWeek.setDate(startOfWeek.getDate() + 7);

        const meetings = [
            {
                id: "m1",
                title: "Product Sync",
                datetime: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 10, 0),
            },
            {
                id: "m2",
                title: "Team Standup",
                datetime: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 9, 30),
            },
            {
                id: "m3",
                title: "Client Call",
                datetime: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 2, 14, 0),
            },
            {
                id: "m4",
                title: "Design Review",
                datetime: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 3, 16, 0),
            },
        ];
        return meetings.filter(
            (m) => m.datetime >= startOfWeek && m.datetime < endOfWeek
        );
    };

    const [meetings, setMeetings] = useState<{ id: string; title: string; datetime: Date }[]>([]);
    useEffect(() => {
        setMeetings(getWeekMeetings());
    }, []);

    return (
        <div
            dir={isRTL ? "rtl" : "ltr"}
            style={{
                direction: isRTL ? "rtl" : "ltr",
                flexGrow: 1,
                alignSelf: "stretch",
                width: "100%",
                height: "100%",
                padding: "32px",
                boxSizing: "border-box",
                overflow: "hidden",
                display: "flex",
                flexDirection: "column",
                background: "#fafbfc",
            }}
        >
            <ProfileSection profile={profile} t={t} />
            <Divider style={{ margin: "0 0 24px 0" }} />
            <EmailsSection emails={emails} t={t} formatDate={formatDate} formatTime={formatTime} />
            <Divider style={{ margin: "0 0 24px 0" }} />
            <MeetingsSection meetings={meetings} t={t} formatDate={formatDate} formatTime={formatTime} />
        </div>
    );
};

export default GeneratedComponent;
import React, { useState, useEffect, useRef } from "react";
import {
    Button,
    Text,
    Input,
    Dropdown,
    Option,
    Card,
    CardHeader,
    CardFooter,
    Divider,
    Tooltip,
} from "@fluentui/react-components";
import {
    AddRegular,
    EditRegular,
    DismissRegular,
    ArrowClockwiseRegular,
    MoreHorizontalRegular,
} from "@fluentui/react-icons";
import type { GeneratedComponentProps, task, ReadableTableRow, WritableTableRow } from "./RuntimeTypes";

// Localization setup
const langMap: Record<number, { code: string; name: string; isRtl: boolean }> = {
    1033: { code: "en-US", name: "English (United States)", isRtl: false },
};
const translations: Record<string, Record<string, string>> = {
    "en-US": {
        appTitle: "Kanban Board",
        addTask: "Add Task",
        editTask: "Edit Task",
        deleteTask: "Delete Task",
        taskTitle: "Task Title",
        taskDescription: "Task Description",
        status: "Status",
        backlog: "Backlog",
        ready: "Ready",
        inprogress: "In-progress",
        awaitingReview: "Awaiting Review",
        complete: "Complete",
        save: "Save",
        cancel: "Cancel",
        noTasks: "No tasks",
        dropHere: "Drop here",
        confirmDelete: "Are you sure you want to delete this task?",
        yes: "Yes",
        no: "No",
        required: "Required",
        errorLoading: "An error occurred while loading tasks.",
        errorLoadingDetails: "Unable to load tasks. Please check your connection or try again.",
        errorSaving: "An error occurred while saving the task.",
        errorSavingDetails: "Unable to create or update the task. Please check your input or try again.",
        errorDeleting: "An error occurred while deleting the task.",
        errorUpdating: "An error occurred while updating the task.",
        retry: "Retry",
        dismiss: "Dismiss",
    },
};
const getLanguage = () => {
    const uiLanguageId =
        (typeof Xrm !== "undefined" &&
            Xrm.Utility?.getGlobalContext()?.userSettings?.languageId) || 1033;
    return langMap[uiLanguageId]?.code || "en-US";
};
const language = getLanguage();
const t = (key: string) =>
    translations[language]?.[key] || translations["en-US"]?.[key] || key;
const isRTL = langMap[
    (typeof Xrm !== "undefined" &&
        Xrm.Utility?.getGlobalContext()?.userSettings?.languageId) || 1033
]?.isRtl || false;

// User settings for formatting
const useUserSettings = (dataApi: any) => {
    const [userSettings, setUserSettings] = useState<any>(null);
    useEffect(() => {
        const fetchUserSettings = async () => {
            const currentUserId =
                (typeof Xrm !== "undefined" &&
                    Xrm.Utility?.getGlobalContext()?.userSettings?.userId)
                    ?.replace("{", "")
                    .replace("}", "");
            if (!currentUserId) return;
            const settings = await dataApi.retrieveRow("usersettings", {
                id: currentUserId,
                select: [
                    "uilanguageid",
                    "localeid",
                    "decimalsymbol",
                    "numberseparator",
                    "currencysymbol",
                    "dateformatstring",
                    "dateseparator",
                ],
            });
            setUserSettings(settings);
        };
        if (dataApi) fetchUserSettings();
    }, [dataApi]);
    return userSettings;
};
const formatDate = (date: Date, userSettings: any) => {
    if (!userSettings) return date.toLocaleDateString(language);
    const sep = userSettings.dateseparator || "/";
    const fmt = (userSettings.dateformatstring || "MM/dd/yyyy")
        .replace("yyyy", date.getFullYear().toString())
        .replace("MM", String(date.getMonth() + 1).padStart(2, "0"))
        .replace("dd", String(date.getDate()).padStart(2, "0"))
        .replace("/", sep)
        .replace("/", sep);
    return fmt;
};

// Kanban statuses
const statusList = [
    { key: "backlog", label: t("backlog") },
    { key: "ready", label: t("ready") },
    { key: "inprogress", label: t("inprogress") },
    { key: "awaitingReview", label: t("awaitingReview") },
    { key: "complete", label: t("complete") },
];

// Main Kanban Component
const GeneratedComponent = ({ dataApi }: GeneratedComponentProps) => {
    // User settings for formatting
    const userSettings = useUserSettings(dataApi);

    // Tasks state
    const [tasks, setTasks] = useState<ReadableTableRow<task>[]>([]);
    const [loading, setLoading] = useState(false);

    // Modal state
    const [showTaskModal, setShowTaskModal] = useState(false);
    const [editingTask, setEditingTask] = useState<ReadableTableRow<task> | null>(null);

    // Task form state
    const [formData, setFormData] = useState<WritableTableRow<task>>({
        subject: "",
        description: "",
        status: "backlog",
    });
    const [formError, setFormError] = useState<string | null>(null);

    // Delete confirmation
    const [deleteTask, setDeleteTask] = useState<ReadableTableRow<task> | null>(null);

    // Drag-and-drop state
    const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
    const [dragOverStatus, setDragOverStatus] = useState<string | null>(null);

    // Error state for loading, saving, deleting, updating
    const [error, setError] = useState<string | null>(null);
    const [errorType, setErrorType] = useState<"loading" | "saving" | "deleting" | "updating" | null>(null);

    // Fetch tasks from Dataverse
    const fetchTasks = async () => {
        setLoading(true);
        setError(null);
        setErrorType(null);
        try {
            const query = {
                select: ["taskid", "subject", "description", "status"],
                pageSize: 100,
                orderBy: "createdon desc",
            };
            const result = await dataApi.queryTable("task", query);
            setTasks(result.rows);
        } catch (err) {
            setError(`${t("errorLoadingDetails")}`);
            setErrorType("loading");
            // Log error for debugging
            // eslint-disable-next-line no-console
            console.error("Error loading tasks:", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (!dataApi) return;
        fetchTasks();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [dataApi]);

    // Task form handlers
    const openTaskModal = (task?: ReadableTableRow<task>) => {
        setEditingTask(task || null);
        setFormData(
            task
                ? {
                      subject: task.subject || "",
                      description: task.description || "",
                      status: task.status || "backlog",
                  }
                : { subject: "", description: "", status: "backlog" }
        );
        setFormError(null);
        setShowTaskModal(true);
    };
    const closeTaskModal = () => {
        setShowTaskModal(false);
        setEditingTask(null);
        setFormError(null);
    };
    const handleFormChange = (field: keyof WritableTableRow<task>, value: string) => {
        setFormData((prev) => ({ ...prev, [field]: value }));
    };
    const handleTaskSave = async () => {
        if (!formData.subject?.trim()) {
            setFormError(t("required"));
            return;
        }
        setLoading(true);
        setError(null);
        setErrorType(null);
        try {
            if (editingTask) {
                await dataApi.updateRow("task", editingTask.taskid, formData);
            } else {
                await dataApi.createRow("task", formData);
            }
            // Refresh tasks
            await fetchTasks();
            closeTaskModal();
        } catch (err) {
            setError(`${t("errorSavingDetails")}`);
            setErrorType("saving");
            // Log error for debugging
            // eslint-disable-next-line no-console
            console.error("Error saving task:", err);
        } finally {
            setLoading(false);
        }
    };

    // Delete task handler
    const handleDeleteTask = async () => {
        if (!deleteTask) return;
        setLoading(true);
        setError(null);
        setErrorType(null);
        try {
            await dataApi.deleteRow("task", deleteTask.taskid);
            // Refresh tasks
            await fetchTasks();
            setDeleteTask(null);
        } catch (err) {
            setError(t("errorDeleting"));
            setErrorType("deleting");
            // Log error for debugging
            // eslint-disable-next-line no-console
            console.error("Error deleting task:", err);
        } finally {
            setLoading(false);
        }
    };

    // Drag-and-drop handlers
    const handleDragStart = (taskId: string) => setDraggedTaskId(taskId);
    const handleDragEnd = () => {
        setDraggedTaskId(null);
        setDragOverStatus(null);
    };
    const handleDragOver = (status: string) => {
        setDragOverStatus(status);
    };
    const handleDrop = async (status: string) => {
        if (!draggedTaskId) return;
        const task = tasks.find((t) => t.taskid === draggedTaskId);
        if (!task || task.status === status) {
            handleDragEnd();
            return;
        }
        setLoading(true);
        setError(null);
        setErrorType(null);
        try {
            await dataApi.updateRow("task", task.taskid, {
                subject: task.subject,
                description: task.description,
                status,
            });
            // Refresh tasks
            await fetchTasks();
        } catch (err) {
            setError(t("errorUpdating"));
            setErrorType("updating");
            // Log error for debugging
            // eslint-disable-next-line no-console
            console.error("Error updating task:", err);
        } finally {
            setLoading(false);
            handleDragEnd();
        }
    };

    // Responsive scroll handling for buckets
    const kanbanContainerRef = useRef<HTMLDivElement>(null);

    // Accessibility: focus management for modal
    useEffect(() => {
        if (showTaskModal) {
            setTimeout(() => {
                const input = document.getElementById("task-title-input");
                if (input) (input as HTMLInputElement).focus();
            }, 100);
        }
    }, [showTaskModal]);

    // Error overlay dismiss handler
    const handleDismissError = () => {
        setError(null);
        setErrorType(null);
    };

    // Render Kanban buckets
    const renderBuckets = () => (
        <div
            ref={kanbanContainerRef}
            style={{
                display: "flex",
                flexDirection: "row",
                gap: "20px",
                overflowX: "auto",
                padding: "16px",
                flex: 1,
                minHeight: 0,
            }}
        >
            {statusList.map((status) => (
                <div
                    key={status.key}
                    style={{
                        minWidth: "280px",
                        flex: "1 1 280px",
                        background: "#F3F2F1",
                        borderRadius: "8px",
                        boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                        padding: "12px",
                        boxSizing: "border-box",
                        display: "flex",
                        flexDirection: "column",
                        height: "100%",
                        border:
                            dragOverStatus === status.key
                                ? "2px solid #0078D4"
                                : "1px solid #E1DFDD",
                        transition: "border-color 0.2s",
                    }}
                    onDragOver={(e) => {
                        e.preventDefault();
                        handleDragOver(status.key);
                    }}
                    onDrop={(e) => {
                        e.preventDefault();
                        handleDrop(status.key);
                    }}
                    onDragLeave={() => setDragOverStatus(null)}
                    aria-label={status.label}
                >
                    <Text as="h2" size={500} weight="semibold" style={{ marginBottom: "8px" }}>
                        {status.label}
                    </Text>
                    <Divider />
                    <div
                        style={{
                            flex: 1,
                            minHeight: 0,
                            overflowY: "auto",
                            marginTop: "8px",
                            display: "flex",
                            flexDirection: "column",
                            gap: "12px",
                        }}
                    >
                        {tasks.filter((t) => t.status === status.key).length === 0 ? (
                            <Text size={300} style={{ color: "#888", textAlign: "center" }}>
                                {t("noTasks")}
                            </Text>
                        ) : (
                            tasks
                                .filter((t) => t.status === status.key)
                                .map((task) => (
                                    <TaskCard
                                        key={task.taskid}
                                        task={task}
                                        onEdit={() => openTaskModal(task)}
                                        onDelete={() => setDeleteTask(task)}
                                        onDragStart={() => handleDragStart(task.taskid)}
                                        onDragEnd={handleDragEnd}
                                        isDragging={draggedTaskId === task.taskid}
                                    />
                                ))
                        )}
                        {dragOverStatus === status.key && draggedTaskId && (
                            <div
                                style={{
                                    height: "48px",
                                    border: "2px dashed #0078D4",
                                    borderRadius: "6px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    background: "#E1DFDD",
                                    marginTop: "8px",
                                    transition: "background 0.2s",
                                }}
                            >
                                <Text size={300} weight="semibold">
                                    {t("dropHere")}
                                </Text>
                            </div>
                        )}
                    </div>
                </div>
            ))}
        </div>
    );

    // Main render
    return (
        <div
            dir={isRTL ? "rtl" : "ltr"}
            style={{
                direction: isRTL ? "rtl" : "ltr",
                width: "100%",
                height: "100%",
                display: "flex",
                flexDirection: "column",
                boxSizing: "border-box",
                background: "#fff",
            }}
        >
            {/* Header */}
            <header
                style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "20px",
                    background: "#0078D4",
                    color: "#fff",
                    borderRadius: "0 0 12px 12px",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                }}
            >
                <Text as="h1" size={700} weight="bold" style={{ color: "#fff" }}>
                    {t("appTitle")}
                </Text>
                <Button
                    appearance="primary"
                    icon={<AddRegular fontSize="20px" />}
                    onClick={() => openTaskModal()}
                    style={{
                        borderRadius: "6px",
                        fontWeight: 600,
                        fontSize: "16px",
                    }}
                    disabled={loading}
                >
                    {t("addTask")}
                </Button>
            </header>
            {/* Kanban Board */}
            <div style={{ flex: 1, minHeight: 0, display: "flex", flexDirection: "column" }}>
                {renderBuckets()}
            </div>
            {/* Task Modal */}
            {showTaskModal && (
                <TaskModal
                    formData={formData}
                    setFormData={setFormData}
                    formError={formError}
                    setFormError={setFormError}
                    onSave={handleTaskSave}
                    onCancel={closeTaskModal}
                    editing={!!editingTask}
                />
            )}
            {/* Delete Confirmation Modal */}
            {deleteTask && (
                <DeleteModal
                    onConfirm={handleDeleteTask}
                    onCancel={() => setDeleteTask(null)}
                    taskTitle={deleteTask.subject}
                />
            )}
            {/* Error message overlay */}
            {error && (
                <div
                    style={{
                        position: "fixed",
                        top: "16px",
                        left: "50%",
                        transform: "translateX(-50%)",
                        background: "#d83b01",
                        color: "#fff",
                        padding: "16px 32px",
                        borderRadius: "8px",
                        boxShadow: "0 2px 8px rgba(0,0,0,0.12)",
                        zIndex: 9999,
                        fontWeight: 600,
                        fontSize: "16px",
                        minWidth: "260px",
                        textAlign: "center",
                        display: "flex",
                        flexDirection: "column",
                        gap: "12px",
                        alignItems: "center",
                    }}
                    role="alert"
                    tabIndex={0}
                >
                    <Text size={400} weight="semibold" block>
                        {error}
                    </Text>
                    <div style={{ display: "flex", gap: "12px" }}>
                        {errorType === "loading" && (
                            <Button appearance="primary" onClick={fetchTasks}>
                                {t("retry")}
                            </Button>
                        )}
                        <Button appearance="subtle" onClick={handleDismissError} icon={<DismissRegular fontSize="18px" />}>
                            {t("dismiss")}
                        </Button>
                    </div>
                </div>
            )}
            {/* Loading overlay */}
            {loading && (
                <div
                    style={{
                        position: "fixed",
                        top: 0,
                        left: 0,
                        width: "100vw",
                        height: "100vh",
                        background: "rgba(255,255,255,0.6)",
                        zIndex: 9999,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        pointerEvents: "auto",
                    }}
                >
                    <ArrowClockwiseRegular fontSize="32px" style={{ color: "#0078D4", animation: "spin 1s linear infinite" }} />
                    <style>
                        {`
                        @keyframes spin {
                            0% { transform: rotate(0deg);}
                            100% { transform: rotate(360deg);}
                        }
                        `}
                    </style>
                </div>
            )}
        </div>
    );
};

// Task Card Component
function TaskCard({
    task,
    onEdit,
    onDelete,
    onDragStart,
    onDragEnd,
    isDragging,
}: {
    task: ReadableTableRow<task>;
    onEdit: () => void;
    onDelete: () => void;
    onDragStart: () => void;
    onDragEnd: () => void;
    isDragging: boolean;
}) {
    return (
        <Card
            draggable
            aria-label={task.subject}
            onDragStart={(e) => {
                e.dataTransfer.effectAllowed = "move";
                onDragStart();
            }}
            onDragEnd={onDragEnd}
            style={{
                opacity: isDragging ? 0.5 : 1,
                boxShadow: isDragging
                    ? "0 4px 12px rgba(0,0,0,0.12)"
                    : "0 2px 8px rgba(0,0,0,0.08)",
                borderRadius: "8px",
                background: "#fff",
                transition: "box-shadow 0.2s, opacity 0.2s",
                cursor: "grab",
                minHeight: "48px",
                display: "flex",
                flexDirection: "column",
            }}
        >
            <CardHeader
                header={
                    <Text size={400} weight="semibold" truncate>
                        {task.subject}
                    </Text>
                }
                style={{ padding: "8px 12px" }}
            />
            {/* Description area */}
            <div style={{ padding: "8px 12px", minHeight: "32px" }}>
                <Text size={300} style={{ color: "#555" }} truncate>
                    {task.description}
                </Text>
            </div>
            <CardFooter
                style={{
                    padding: "8px 12px",
                    display: "flex",
                    justifyContent: "flex-end",
                    gap: "8px",
                }}
            >
                <Tooltip content={t("editTask")}>
                    <Button
                        appearance="subtle"
                        icon={<EditRegular fontSize="18px" />}
                        onClick={onEdit}
                        aria-label={t("editTask")}
                        style={{ borderRadius: "4px" }}
                    />
                </Tooltip>
                <Tooltip content={t("deleteTask")}>
                    <Button
                        appearance="subtle"
                        icon={<DismissRegular fontSize="18px" />}
                        onClick={onDelete}
                        aria-label={t("deleteTask")}
                        style={{ borderRadius: "4px" }}
                    />
                </Tooltip>
            </CardFooter>
        </Card>
    );
}

// Task Modal Component
function TaskModal({
    formData,
    setFormData,
    formError,
    setFormError,
    onSave,
    onCancel,
    editing,
}: {
    formData: WritableTableRow<task>;
    setFormData: (data: WritableTableRow<task>) => void;
    formError: string | null;
    setFormError: (err: string | null) => void;
    onSave: () => void;
    onCancel: () => void;
    editing: boolean;
}) {
    // Focus trap for accessibility
    const modalRef = useRef<HTMLDivElement>(null);
    useEffect(() => {
        if (modalRef.current) modalRef.current.focus();
    }, []);
    return (
        <div
            tabIndex={-1}
            ref={modalRef}
            aria-modal="true"
            role="dialog"
            style={{
                position: "fixed",
                top: 0,
                left: 0,
                width: "100vw",
                height: "100vh",
                background: "rgba(0,0,0,0.18)",
                zIndex: 10000,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
            }}
            onKeyDown={(e) => {
                if (e.key === "Escape") onCancel();
            }}
        >
            <div
                style={{
                    background: "#fff",
                    borderRadius: "12px",
                    boxShadow: "0 4px 16px rgba(0,0,0,0.16)",
                    padding: "32px 24px",
                    minWidth: "320px",
                    maxWidth: "90vw",
                    width: "400px",
                    display: "flex",
                    flexDirection: "column",
                    gap: "16px",
                }}
            >
                <Text as="h2" size={600} weight="bold" block>
                    {editing ? t("editTask") : t("addTask")}
                </Text>
                <Input
                    id="task-title-input"
                    value={formData.subject || ""}
                    onChange={(e, d) => setFormData({ ...formData, subject: d.value })}
                    placeholder={t("taskTitle")}
                    aria-label={t("taskTitle")}
                    required
                    style={{ marginBottom: "8px" }}
                />
                <Input
                    value={formData.description || ""}
                    onChange={(e, d) => setFormData({ ...formData, description: d.value })}
                    placeholder={t("taskDescription")}
                    aria-label={t("taskDescription")}
                    style={{ marginBottom: "8px" }}
                />
                <Dropdown
                    value={statusList.find((s) => s.key === formData.status)?.label || ""}
                    onOptionSelect={(e, data) => {
                        setFormData({ ...formData, status: data.optionValue });
                    }}
                    aria-label={t("status")}
                    placeholder={t("status")}
                    style={{ marginBottom: "8px" }}
                >
                    {statusList.map((status) => (
                        <Option key={status.key} value={status.key}>
                            {status.label}
                        </Option>
                    ))}
                </Dropdown>
                {formError && (
                    <Text size={300} style={{ color: "#d83b01" }}>
                        {formError}
                    </Text>
                )}
                <div style={{ display: "flex", justifyContent: "flex-end", gap: "12px" }}>
                    <Button appearance="secondary" onClick={onCancel}>
                        {t("cancel")}
                    </Button>
                    <Button appearance="primary" onClick={onSave}>
                        {t("save")}
                    </Button>
                </div>
            </div>
        </div>
    );
}

// Delete Confirmation Modal
function DeleteModal({
    onConfirm,
    onCancel,
    taskTitle,
}: {
    onConfirm: () => void;
    onCancel: () => void;
    taskTitle: string;
}) {
    const modalRef = useRef<HTMLDivElement>(null);
    useEffect(() => {
        if (modalRef.current) modalRef.current.focus();
    }, []);
    return (
        <div
            tabIndex={-1}
            ref={modalRef}
            aria-modal="true"
            role="dialog"
            style={{
                position: "fixed",
                top: 0,
                left: 0,
                width: "100vw",
                height: "100vh",
                background: "rgba(0,0,0,0.18)",
                zIndex: 10000,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
            }}
            onKeyDown={(e) => {
                if (e.key === "Escape") onCancel();
            }}
        >
            <div
                style={{
                    background: "#fff",
                    borderRadius: "12px",
                    boxShadow: "0 4px 16px rgba(0,0,0,0.16)",
                    padding: "32px 24px",
                    minWidth: "320px",
                    maxWidth: "90vw",
                    width: "400px",
                    display: "flex",
                    flexDirection: "column",
                    gap: "16px",
                }}
            >
                <Text as="h2" size={600} weight="bold" block>
                    {t("deleteTask")}
                </Text>
                <Text size={400} block>
                    {t("confirmDelete")}
                </Text>
                <Text size={300} block weight="semibold">
                    {taskTitle}
                </Text>
                <div style={{ display: "flex", justifyContent: "flex-end", gap: "12px" }}>
                    <Button appearance="secondary" onClick={onCancel}>
                        {t("no")}
                    </Button>
                    <Button appearance="primary" onClick={onConfirm}>
                        {t("yes")}
                    </Button>
                </div>
            </div>
        </div>
    );
}

export default GeneratedComponent;
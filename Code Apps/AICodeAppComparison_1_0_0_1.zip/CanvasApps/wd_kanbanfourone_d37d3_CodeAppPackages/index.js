import { initDataSources, registerTable, listItems, createItem, updateItem } from './codeapp.js';
import { enableDebugger } from "./codeapp.js";

enableDebugger();

const aStatuses = [
  { key: 1, label: 'Backlog', statecode: 0, statuscode: 2 },
  { key: 2, label: 'Ready', statecode: 0, statuscode: 2 },
  { key: 3, label: 'In-progress', statecode: 0, statuscode: 3 },
  { key: 4, label: 'Awaiting Review', statecode: 0, statuscode: 4 },
  { key: 5, label: 'Complete', statecode: 1, statuscode: 5 }
];

const sTable = 'tasks';
const sPrimaryKey = 'activityid';

async function boot() {
  initDataSources({ tasks: { entitySetName: 'tasks', logicalName: 'task' } });
  registerTable(sTable, sPrimaryKey);
  renderKanban();
}

async function fetchTasks() {
  const { entities } = await listItems(sTable, sPrimaryKey, { select: ['subject', 'statuscode', 'activityid'] });
  return entities;
}

async function addTask(sTitle, iStatusKey) {
  const oStatus = aStatuses.find(s => s.key === iStatusKey) || aStatuses[0];
  await createItem(sTable, sPrimaryKey, {
    subject: sTitle,
    statecode: oStatus.statecode,
    statuscode: oStatus.statuscode,
    activitytypecode: 4212, // Task
    isregularactivity: true
  });
  renderKanban();
}

async function updateTaskStatus(id, iStatusKey) {
  const oStatus = aStatuses.find(s => s.key === iStatusKey) || aStatuses[0];
  await updateItem(sTable, sPrimaryKey, id, {
    statecode: oStatus.statecode,
    statuscode: oStatus.statuscode
  });
  renderKanban();
}

function renderKanban() {
  fetchTasks().then(aTasks => {
    const eRoot = document.getElementById('root');
    eRoot.innerHTML = '';
    const eBoard = document.createElement('div');
    eBoard.className = 'kanban-board';
    aStatuses.forEach(oStatus => {
      const eCol = document.createElement('div');
      eCol.className = 'kanban-column';
      eCol.dataset.status = oStatus.key;
      const eTitle = document.createElement('div');
      eTitle.className = 'kanban-column-title';
      eTitle.textContent = oStatus.label;
      eCol.appendChild(eTitle);
      const eList = document.createElement('div');
      eList.className = 'kanban-task-list';
      aTasks.filter(t => t.statuscode === oStatus.key).forEach(t => {
        const eTask = document.createElement('div');
        eTask.className = 'kanban-task';
        eTask.textContent = t.subject;
        eTask.draggable = true;
        eTask.dataset.id = t.activityid;
        eTask.addEventListener('dragstart', ev => {
          eTask.classList.add('dragging');
          ev.dataTransfer.setData('text/plain', t.activityid);
        });
        eTask.addEventListener('dragend', () => {
          eTask.classList.remove('dragging');
        });
        eList.appendChild(eTask);
      });
      eCol.appendChild(eList);
      // Drag & drop events
      eCol.addEventListener('dragover', ev => {
        ev.preventDefault();
        eCol.style.background = '#e0ffb3';
      });
      eCol.addEventListener('dragleave', () => {
        eCol.style.background = '#fff';
      });
      eCol.addEventListener('drop', ev => {
        ev.preventDefault();
        eCol.style.background = '#fff';
        const id = ev.dataTransfer.getData('text/plain');
        updateTaskStatus(id, oStatus.key);
      });
      // Add task UI (only in Backlog)
      if (oStatus.key === 1) {
        const eAdd = document.createElement('form');
        eAdd.className = 'kanban-add-task';
        const eInput = document.createElement('input');
        eInput.type = 'text';
        eInput.placeholder = 'New task title...';
        eAdd.appendChild(eInput);
        const eBtn = document.createElement('button');
        eBtn.type = 'submit';
        eBtn.textContent = 'Add';
        eAdd.appendChild(eBtn);
        eAdd.onsubmit = ev => {
          ev.preventDefault();
          if (eInput.value.trim()) {
            addTask(eInput.value.trim(), 1);
            eInput.value = '';
          }
        };
        eCol.appendChild(eAdd);
      }
      eBoard.appendChild(eCol);
    });
    eRoot.appendChild(eBoard);
  });
}

boot();
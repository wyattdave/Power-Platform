import { getMyProfile, getUserPhoto } from './connectors/office365users.js';
import { listEmails, getCalendarView } from './connectors/outlook.js';

// ── Helpers ─────────────────────────────────────────────────────

function esc(str) {
  if (!str) return '';
  const el = document.createElement('span');
  el.textContent = str;
  return el.innerHTML;
}

function getInitials(name) {
  if (!name) return '?';
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
}

function formatEmailDate(isoStr) {
  if (!isoStr) return '';
  const d = new Date(isoStr);
  const now = new Date();
  const diff = now - d;
  const oneDay = 86400000;

  if (diff < oneDay && d.getDate() === now.getDate()) {
    return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }
  if (diff < oneDay * 2 && d.getDate() === now.getDate() - 1) {
    return 'Yesterday';
  }
  if (diff < oneDay * 7) {
    return d.toLocaleDateString([], { weekday: 'short' });
  }
  return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

function formatMeetingDay(isoStr) {
  const d = new Date(isoStr);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const eventDay = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const diffDays = Math.round((eventDay - today) / 86400000);

  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Tomorrow';
  return d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
}

function formatTime(isoStr) {
  return new Date(isoStr).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function formatDuration(startIso, endIso) {
  const mins = Math.round((new Date(endIso) - new Date(startIso)) / 60000);
  if (mins < 60) return mins + ' minutes';
  const hrs = mins / 60;
  if (hrs === Math.floor(hrs)) return hrs + (hrs === 1 ? ' hour' : ' hours');
  return hrs.toFixed(1) + ' hours';
}

function getWeekBounds() {
  const now = new Date();
  const dayOfWeek = now.getDay();
  const monday = new Date(now);
  monday.setDate(now.getDate() - ((dayOfWeek + 6) % 7));
  monday.setHours(0, 0, 0, 0);

  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  sunday.setHours(23, 59, 59, 999);

  return { start: monday.toISOString(), end: sunday.toISOString() };
}

function getSenderName(email) {
  if (email.from && email.from.emailAddress && email.from.emailAddress.name) {
    return email.from.emailAddress.name;
  }
  if (email.From && email.From.Name) return email.From.Name;
  if (typeof email.from === 'string') return email.from;
  return 'Unknown';
}

// ── Set Edition Date ────────────────────────────────────────────
const now = new Date();
const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
document.getElementById('edition-date').textContent =
  'Personal Briefing · ' + dayNames[now.getDay()] + ', ' + now.getDate() + ' ' + monthNames[now.getMonth()] + ' ' + now.getFullYear();

// ── Render Profile ──────────────────────────────────────────────
async function loadProfile() {
  const section = document.getElementById('profile-section');
  try {
    const profile = await getMyProfile({
      select: 'displayName,jobTitle,department,mail,mobilePhone,businessPhones,officeLocation,city,country'
    });

    let photoUrl = null;
    try {
      const photoData = await getUserPhoto(profile.mail || profile.userPrincipalName || profile.Id);
      if (photoData) {
        if (typeof photoData === 'string' && photoData.startsWith('data:')) {
          photoUrl = photoData;
        } else if (photoData instanceof Blob || photoData instanceof ArrayBuffer) {
          const blob = photoData instanceof Blob ? photoData : new Blob([photoData], { type: 'image/jpeg' });
          photoUrl = URL.createObjectURL(blob);
        } else if (typeof photoData === 'string') {
          photoUrl = 'data:image/jpeg;base64,' + photoData;
        }
      }
    } catch (_) { /* photo not available */ }

    const displayName = profile.displayName || profile.DisplayName || '';
    const jobTitle = profile.jobTitle || profile.JobTitle || '';
    const department = profile.department || profile.Department || '';
    const mail = profile.mail || profile.Mail || profile.userPrincipalName || '';
    const phone = profile.mobilePhone || profile.MobilePhone || (profile.businessPhones && profile.businessPhones[0]) || (profile.BusinessPhones && profile.BusinessPhones[0]) || '';
    const office = profile.officeLocation || profile.OfficeLocation || '';

    const photoHtml = photoUrl
      ? '<img src="' + esc(photoUrl) + '" alt="Profile photo">'
      : esc(getInitials(displayName));

    const bylineParts = [jobTitle, department].filter(Boolean);

    section.innerHTML =
      '<div class="profile-row">' +
        '<div class="profile-photo">' + photoHtml + '</div>' +
        '<div class="profile-headline">' +
          '<h2>' + esc(displayName) + '</h2>' +
          (bylineParts.length ? '<p class="byline">' + esc(bylineParts.join(' — ')) + '</p>' : '') +
          '<div class="profile-meta">' +
            (mail ? '<span><span class="icon">✉</span> ' + esc(mail) + '</span>' : '') +
            (phone ? '<span><span class="icon">☎</span> ' + esc(phone) + '</span>' : '') +
            (office ? '<span><span class="icon">🏢</span> ' + esc(office) + '</span>' : '') +
          '</div>' +
        '</div>' +
      '</div>';
  } catch (err) {
    section.innerHTML = '<div class="empty-state">Could not load profile: ' + esc(err.message) + '</div>';
  }
}

// ── Render Emails ───────────────────────────────────────────────
async function loadEmails() {
  const section = document.getElementById('emails-section');
  const countEl = document.getElementById('email-count');
  try {
    const result = await listEmails({ top: 10, folderId: 'Inbox' });
    const emails = Array.isArray(result) ? result : (result && result.value ? result.value : []);

    countEl.textContent = emails.length + ' Message' + (emails.length !== 1 ? 's' : '');

    if (emails.length === 0) {
      section.innerHTML = '<div class="empty-state">No recent emails.</div>';
      return;
    }

    let html = '<div class="email-columns">';
    emails.forEach(function(email) {
      const sender = getSenderName(email);
      const subject = email.subject || email.Subject || '(No Subject)';
      const received = email.receivedDateTime || email.DateTimeReceived || email.ReceivedDateTime || '';
      const preview = email.bodyPreview || email.BodyPreview || email.Preview || '';

      html +=
        '<div class="email-entry">' +
          '<div class="from-line">' +
            '<span class="from">' + esc(sender) + '</span>' +
            '<span class="when">' + esc(formatEmailDate(received)) + '</span>' +
          '</div>' +
          '<div class="subj">' + esc(subject) + '</div>' +
          '<div class="preview">' + esc(preview.slice(0, 120)) + '</div>' +
        '</div>';
    });
    html += '</div>';
    section.innerHTML = html;
  } catch (err) {
    section.innerHTML = '<div class="empty-state">Could not load emails: ' + esc(err.message) + '</div>';
  }
}

// ── Render Meetings ─────────────────────────────────────────────
async function loadMeetings() {
  const section = document.getElementById('meetings-section');
  const countEl = document.getElementById('meeting-count');
  try {
    const { start, end } = getWeekBounds();
    const result = await getCalendarView({
      startDateTimeUtc: start,
      endDateTimeUtc: end,
      top: 50,
      orderBy: 'start/dateTime asc'
    });
    const events = Array.isArray(result) ? result : (result && result.value ? result.value : []);

    countEl.textContent = events.length + ' Event' + (events.length !== 1 ? 's' : '');

    if (events.length === 0) {
      section.innerHTML = '<div class="empty-state">No meetings this week.</div>';
      return;
    }

    let html = '<div class="meetings-list">';
    events.forEach(function(evt) {
      const title = evt.subject || evt.Subject || '(No Title)';
      const startTime = (evt.start && evt.start.dateTime) || evt.Start || evt.startDateTime || '';
      const endTime = (evt.end && evt.end.dateTime) || evt.End || evt.endDateTime || '';

      html +=
        '<div class="meeting-entry">' +
          '<div class="meeting-time-col">' +
            '<span class="day">' + esc(formatMeetingDay(startTime)) + '</span>' +
            '<span class="time">' + esc(formatTime(startTime) + ' – ' + formatTime(endTime)) + '</span>' +
          '</div>' +
          '<div class="meeting-detail">' +
            '<h4>' + esc(title) + '</h4>' +
            '<span class="duration">' + esc(formatDuration(startTime, endTime)) + '</span>' +
          '</div>' +
        '</div>';
    });
    html += '</div>';
    section.innerHTML = html;
  } catch (err) {
    section.innerHTML = '<div class="empty-state">Could not load calendar: ' + esc(err.message) + '</div>';
  }
}

// ── Boot ────────────────────────────────────────────────────────
async function boot() {
  await Promise.allSettled([loadProfile(), loadEmails(), loadMeetings()]);
}

boot();

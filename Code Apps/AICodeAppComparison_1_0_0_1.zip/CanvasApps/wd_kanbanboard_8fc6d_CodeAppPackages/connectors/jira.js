// ────────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────── Jira ───────────────────────────────────
// ────────────────────────────────────────────────────────────────────────────
import {_dbgWrap  } from "../codeapp.js";
const JIRA_DATA_SOURCE_CANDIDATES = ["jira", "Jira", "JIRA"];
const JIRA_APIS = {
  AddComment_V2: {
    path: "/{connectionId}/v2/issue/{issueKey}/comment",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "issueKey", in: "path", required: true },
      { name: "body", in: "body", required: true },
    ],
  },
  CancelTask_V2: {
    path: "/{connectionId}/v2/task/{taskId}/cancel",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "taskId", in: "path", required: true },
      { name: "X-Atlassian-Token", in: "header", required: true },
    ],
  },
  CreateIssue_V3: {
    path: "/{connectionId}/v3/issue",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "projectKey", in: "query", required: true },
      { name: "issueTypeIds", in: "query", required: true },
      { name: "item", in: "body", required: false },
    ],
  },
  EditIssue_V2: {
    path: "/{connectionId}/v2/3/issue/{issueIdOrKey}",
    method: "PUT",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "issueIdOrKey", in: "path", required: true },
      { name: "notifyUsers", in: "query", required: false },
      { name: "overrideScreenSecurity", in: "query", required: false },
      { name: "overrideEditableFlag", in: "query", required: false },
      { name: "body", in: "body", required: false },
    ],
  },
  GetCurrentUser: {
    path: "/{connectionId}/3/myself",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "expand", in: "query", required: false },
    ],
  },
  GetIssue_V2: {
    path: "/{connectionId}/v2/issue/{issueKey}",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "issueKey", in: "path", required: true },
    ],
  },
  ListFilters_V2: {
    path: "/{connectionId}/v2/filter/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
    ],
  },
  ListIssues: {
    path: "/{connectionId}/2/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "jql", in: "query", required: false },
      { name: "expand", in: "query", required: false },
      { name: "fields", in: "query", required: false },
    ],
  },
  ListProjects_V2: {
    path: "/{connectionId}/project/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
    ],
  },
  GetTask_V2: {
    path: "/{connectionId}/v2/task/{taskId}",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "taskId", in: "path", required: true },
    ],
  },
  GetUser_V2: {
    path: "/{connectionId}/v2/user",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "accountId", in: "query", required: true },
      { name: "expand", in: "query", required: false },
    ],
  },
};

Object.assign(JIRA_APIS, {
  EditIssue: {
    path: "/{connectionId}/3/issue/{issueIdOrKey}",
    method: "PUT",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "issueIdOrKey", in: "path", required: true },
      { name: "notifyUsers", in: "query", required: false },
      { name: "overrideScreenSecurity", in: "query", required: false },
      { name: "overrideEditableFlag", in: "query", required: false },
      { name: "body", in: "body", required: false },
    ],
  },
  DeleteProject: {
    path: "/{connectionId}/3/project/{projectIdOrKey}",
    method: "DELETE",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectIdOrKey", in: "path", required: true },
      { name: "enableUndo", in: "query", required: false },
    ],
  },
  UpdateProject: {
    path: "/{connectionId}/3/project/{projectIdOrKey}",
    method: "PUT",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectIdOrKey", in: "path", required: true },
      { name: "body", in: "body", required: false },
    ],
  },
  DeleteProject_V2: {
    path: "/{connectionId}/v2/project/{projectIdOrKey}",
    method: "DELETE",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "projectIdOrKey", in: "path", required: true },
      { name: "enableUndo", in: "query", required: false },
    ],
  },
  UpdateProject_V2: {
    path: "/{connectionId}/v2/project/{projectIdOrKey}",
    method: "PUT",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "projectIdOrKey", in: "path", required: true },
      { name: "body", in: "body", required: false },
    ],
  },
  GetAllProjectCategories: {
    path: "/{connectionId}/3/projectCategory",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
    ],
  },
  CreateProjectCategory: {
    path: "/{connectionId}/3/projectCategory",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "body", in: "body", required: false },
    ],
  },
  GetAllProjectCategories_V2: {
    path: "/{connectionId}/v2/projectCategory",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
    ],
  },
  CreateProjectCategory_V2: {
    path: "/{connectionId}/v2/projectCategory",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "body", in: "body", required: false },
    ],
  },
  RemoveProjectCategory: {
    path: "/{connectionId}/3/projectCategory/{id}",
    method: "DELETE",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "id", in: "path", required: true },
    ],
  },
  RemoveProjectCategory_V2: {
    path: "/{connectionId}/v2/projectCategory/{id}",
    method: "DELETE",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "id", in: "path", required: true },
    ],
  },
  GetTask: {
    path: "/{connectionId}/3/task/{taskId}",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "taskId", in: "path", required: true },
    ],
  },
  CancelTask: {
    path: "/{connectionId}/3/task/{taskId}/cancel",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "taskId", in: "path", required: true },
      { name: "X-Atlassian-Token", in: "header", required: true },
    ],
  },
  GetUser: {
    path: "/{connectionId}/3/user",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "accountId", in: "query", required: true },
      { name: "expand", in: "query", required: false },
    ],
  },
  CreateIssue: {
    path: "/{connectionId}/issue",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
      { name: "body", in: "body", required: true },
    ],
  },
  CreateIssueV2: {
    path: "/{connectionId}/v2/issue",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
      { name: "issueTypeIds", in: "query", required: true },
      { name: "item", in: "body", required: false },
    ],
  },
  GetIssue: {
    path: "/{connectionId}/issue/{issueKey}",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "issueKey", in: "path", required: true },
    ],
  },
  UpdateIssue: {
    path: "/{connectionId}/issue/{issueKey}",
    method: "PUT",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "issueKey", in: "path", required: true },
      { name: "body", in: "body", required: true },
    ],
  },
  UpdateIssue_V2: {
    path: "/{connectionId}/v2/issue/{issueKey}",
    method: "PUT",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "issueKey", in: "path", required: true },
      { name: "body", in: "body", required: true },
    ],
  },
  AddComment: {
    path: "/{connectionId}/issue/{issueKey}/comment",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "issueKey", in: "path", required: true },
      { name: "body", in: "body", required: true },
    ],
  },
  ListIssueTypes: {
    path: "/{connectionId}/issue/createmeta",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
    ],
  },
  ListIssueTypes_V2: {
    path: "/{connectionId}/v2/types/issue/createmeta",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "projectKey", in: "query", required: true },
    ],
  },
  ListIssueTypesFields: {
    path: "/{connectionId}/v2/issue/createmeta",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
      { name: "issuetypeIds", in: "query", required: true },
    ],
  },
  ListIssueTypesFields_V2: {
    path: "/{connectionId}/v3/issue/createmeta",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "projectKey", in: "query", required: true },
      { name: "issuetypeIds", in: "query", required: true },
    ],
  },
  ListProjects: {
    path: "/{connectionId}/project",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
    ],
  },
  CreateProject: {
    path: "/{connectionId}/project",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "Project", in: "body", required: true },
    ],
  },
  CreateProject_V2: {
    path: "/{connectionId}/v2/project",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "Project", in: "body", required: true },
    ],
  },
  ListProjects_V3: {
    path: "/{connectionId}/v2/project/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
    ],
  },
  ListStatuses: {
    path: "/{connectionId}/project/{projectId}/statuses",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "issueType", in: "query", required: true },
      { name: "projectId", in: "path", required: true },
    ],
  },
  ListStatuses_V2: {
    path: "/{connectionId}/v2/project/{projectId}/statuses",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "projectId", in: "path", required: true },
      { name: "issueType", in: "query", required: false },
    ],
  },
  ListProjectUsers: {
    path: "/{connectionId}/user/permission/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
    ],
  },
  ListProjectUsers_V2: {
    path: "/{connectionId}/v2/user/permission/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "projectKey", in: "query", required: true },
    ],
  },
  ListAssignableUsers: {
    path: "/{connectionId}/user/assignable/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
    ],
  },
  ListAssignableUsers_V2: {
    path: "/{connectionId}/v2/user/assignable/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "projectKey", in: "query", required: true },
    ],
  },
  ListPriorityTypes: {
    path: "/{connectionId}/priority",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
    ],
  },
  ListPriorityTypes_V2: {
    path: "/{connectionId}/v2/priority",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
    ],
  },
  ListFilters: {
    path: "/{connectionId}/2/filter/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
    ],
  },
  ListResources: {
    path: "/{connectionId}/oauth/token/accessible-resources",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
    ],
  },
  ListIssues_Datacenter: {
    path: "/{connectionId}/datacenter/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
    ],
  },
  ListTransitions: {
    path: "/{connectionId}/3/issue/{issueIdOrKey}/transitions",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "issueIdOrKey", in: "path", required: true },
    ],
  },
  UpdateTransition: {
    path: "/{connectionId}/3/issue/{issueIdOrKey}/transitions",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "X-Request-Jirainstance", in: "header", required: true },
      { name: "issueIdOrKey", in: "path", required: true },
      { name: "body", in: "body", required: true },
    ],
  },
  OnNewIssue: {
    path: "/{connectionId}/new_issue_trigger/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
    ],
  },
  OnNewIssue_V2: {
    path: "/{connectionId}/v2/new_issue_trigger/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
      { name: "X-Request-Jirainstance", in: "query", required: false },
    ],
  },
  OnNewIssue_Datacenter: {
    path: "/{connectionId}/datacenter/new_issue_trigger/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
      { name: "X-Request-Jirainstance", in: "query", required: false },
    ],
  },
  OnCloseIssue: {
    path: "/{connectionId}/close_issue_trigger/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
    ],
  },
  OnCloseIssue_V2: {
    path: "/{connectionId}/v2/close_issue_trigger/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
      { name: "X-Request-Jirainstance", in: "query", required: false },
    ],
  },
  OnCloseIssue_Datacenter: {
    path: "/{connectionId}/datacenter/close_issue_trigger/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
      { name: "X-Request-Jirainstance", in: "query", required: false },
    ],
  },
  OnUpdateIssue: {
    path: "/{connectionId}/update_issue_trigger/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
    ],
  },
  OnUpdateIssue_V2: {
    path: "/{connectionId}/v2/update_issue_trigger/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
      { name: "X-Request-Jirainstance", in: "query", required: false },
    ],
  },
  OnUpdateIssue_Datacenter: {
    path: "/{connectionId}/datacenter/update_issue_trigger/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "projectKey", in: "query", required: true },
      { name: "X-Request-Jirainstance", in: "query", required: false },
    ],
  },
  OnNewIssueJQL: {
    path: "/{connectionId}/new_issue_jql_trigger/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "jql", in: "query", required: true },
    ],
  },
  OnNewIssueJQL_V2: {
    path: "/{connectionId}/v2/new_issue_jql_trigger/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "jql", in: "query", required: true },
      { name: "X-Request-Jirainstance", in: "query", required: false },
    ],
  },
  OnNewIssueJQL_Datacenter: {
    path: "/{connectionId}/datacenter/new_issue_jql_trigger/search",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "jql", in: "query", required: true },
      { name: "X-Request-Jirainstance", in: "query", required: false },
    ],
  },
  mcp_JiraIssueManagement: {
    path: "/{connectionId}/mcp/JiraIssueManagement",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "queryRequest", in: "body", required: false },
      { name: "sessionId", in: "query", required: false },
    ],
  },
});

function isJiraObject(oValue) {
  return !!oValue && typeof oValue === "object" && !Array.isArray(oValue);
}

function pickJiraValue() {
  for (let iIndex = 0; iIndex < arguments.length; iIndex += 1) {
    const oValue = arguments[iIndex];
    if (oValue !== undefined && oValue !== null) {
      return oValue;
    }
  }

  return undefined;
}

function setJiraIfDefined(oTarget, sKey, oValue) {
  if (oValue !== undefined && oValue !== null) {
    oTarget[sKey] = oValue;
  }

  return oTarget;
}

function normalizeJiraList(oValue) {
  if (Array.isArray(oValue)) {
    return oValue.join(",");
  }

  return oValue;
}

function normalizeJiraInstance(oOptions, sFallback) {
  if (typeof oOptions === "string") {
    return oOptions;
  }

  if (!isJiraObject(oOptions)) {
    return sFallback;
  }

  return pickJiraValue(
    oOptions.jiraInstance,
    oOptions.instance,
    oOptions.jiraUrl,
    oOptions.site,
    oOptions["X-Request-Jirainstance"],
    sFallback
  );
}

function withJiraInstance(oParams, sJiraInstance) {
  if (sJiraInstance) {
    oParams["X-Request-Jirainstance"] = sJiraInstance;
  }

  return oParams;
}

function normalizeJiraCommentBody(oBody) {
  if (typeof oBody === "string") {
    return { body: oBody };
  }

  if (!isJiraObject(oBody)) {
    return oBody;
  }

  if (oBody.body !== undefined) {
    return oBody;
  }

  if (typeof oBody.comment === "string") {
    return { body: oBody.comment };
  }

  if (typeof oBody.text === "string") {
    return { body: oBody.text };
  }

  return oBody;
}

function normalizeJiraEditBody(oOptions) {
  if (!isJiraObject(oOptions)) {
    return oOptions;
  }

  if (isJiraObject(oOptions.body)) {
    return oOptions.body;
  }

  const oBody = {};
  setJiraIfDefined(oBody, "transition", oOptions.transition);
  setJiraIfDefined(oBody, "fields", oOptions.fields);
  setJiraIfDefined(oBody, "update", oOptions.update);
  setJiraIfDefined(oBody, "historyMetadata", oOptions.historyMetadata);
  setJiraIfDefined(oBody, "properties", oOptions.properties);
  return Object.keys(oBody).length > 0 ? oBody : undefined;
}

function normalizeJiraIssuePayload(oOptions) {
  if (!isJiraObject(oOptions)) {
    return oOptions;
  }

  if (isJiraObject(oOptions.body)) {
    return oOptions.body;
  }

  if (isJiraObject(oOptions.item)) {
    return oOptions.item;
  }

  if (isJiraObject(oOptions.issue)) {
    return oOptions.issue;
  }

  if (isJiraObject(oOptions.fields)) {
    return { fields: oOptions.fields };
  }

  return undefined;
}

function normalizeJiraProjectBody(oOptions) {
  if (!isJiraObject(oOptions)) {
    return oOptions;
  }

  if (isJiraObject(oOptions.body)) {
    return oOptions.body;
  }

  if (isJiraObject(oOptions.Project)) {
    return oOptions.Project;
  }

  const oBody = {};
  [
    "key",
    "name",
    "projectTypeKey",
    "projectTemplateKey",
    "description",
    "lead",
    "leadAccountId",
    "url",
    "assigneeType",
    "avatarId",
    "issueSecurityScheme",
    "permissionScheme",
    "notificationScheme",
    "categoryId",
  ].forEach(function(sKey) {
    setJiraIfDefined(oBody, sKey, oOptions[sKey]);
  });

  return Object.keys(oBody).length > 0 ? oBody : undefined;
}

function normalizeJiraProjectCategoryBody(oOptions) {
  if (!isJiraObject(oOptions)) {
    return oOptions;
  }

  if (isJiraObject(oOptions.body)) {
    return oOptions.body;
  }

  const oBody = {};
  setJiraIfDefined(oBody, "name", oOptions.name);
  setJiraIfDefined(oBody, "description", oOptions.description);
  return Object.keys(oBody).length > 0 ? oBody : undefined;
}

function normalizeJiraTransitionBody(oOptions) {
  if (!isJiraObject(oOptions)) {
    return oOptions;
  }

  if (isJiraObject(oOptions.body)) {
    return oOptions.body;
  }

  const oBody = {};
  setJiraIfDefined(oBody, "fields", oOptions.fields);
  setJiraIfDefined(oBody, "historyMetadata", oOptions.historyMetadata);
  setJiraIfDefined(oBody, "transition", oOptions.transition);
  setJiraIfDefined(oBody, "update", oOptions.update);
  return Object.keys(oBody).length > 0 ? oBody : undefined;
}

async function execJiraOp(operationName, parameters) {
  return execConnectorOpWithCandidates(JIRA_DATA_SOURCE_CANDIDATES, JIRA_APIS, "Jira", operationName, parameters);
}

export async function callJiraOperation(operationName, parameters = {}) {
  return _dbgWrap('callJiraOperation', [operationName, parameters], async function() {
  return execJiraOp(operationName, parameters);
  });
}

export async function addJiraComment(sIssueKey, body, sJiraInstance) {
  return _dbgWrap('addJiraComment', [sIssueKey, body, sJiraInstance], async function() {
  if (isJiraObject(sIssueKey)) {
    sJiraInstance = normalizeJiraInstance(sIssueKey, sJiraInstance);
    body = pickJiraValue(sIssueKey.body, sIssueKey.comment, sIssueKey.text);
    sIssueKey = pickJiraValue(sIssueKey.issueKey, sIssueKey.issueIdOrKey, sIssueKey.id, sIssueKey.key);
  } else if (isJiraObject(body) && !Object.prototype.hasOwnProperty.call(body, "body") && sJiraInstance === undefined) {
    sJiraInstance = normalizeJiraInstance(body, sJiraInstance);
    body = pickJiraValue(body.body, body.comment, body.text, body);
  }

  const sOperationName = sJiraInstance ? "AddComment_V2" : "AddComment";
  return execJiraOp(sOperationName, withJiraInstance({
    issueKey: sIssueKey,
    body: normalizeJiraCommentBody(body),
  }, sJiraInstance));
  });
}

export async function cancelJiraTask(sTaskId, sJiraInstance, sToken) {
  return _dbgWrap('cancelJiraTask', [sTaskId, sJiraInstance, sToken], async function() {
  if (isJiraObject(sTaskId)) {
    sToken = pickJiraValue(sTaskId.token, sTaskId.atlassianToken, sTaskId["X-Atlassian-Token"], sToken);
    sJiraInstance = normalizeJiraInstance(sTaskId, sJiraInstance);
    sTaskId = pickJiraValue(sTaskId.taskId, sTaskId.id);
  } else if (isJiraObject(sJiraInstance)) {
    sToken = pickJiraValue(sJiraInstance.token, sJiraInstance.atlassianToken, sJiraInstance["X-Atlassian-Token"], sToken);
    sJiraInstance = normalizeJiraInstance(sJiraInstance);
  }

  const sOperationName = sJiraInstance ? "CancelTask_V2" : "CancelTask";
  return execJiraOp(sOperationName, withJiraInstance({
    taskId: sTaskId,
    "X-Atlassian-Token": sToken || "nocheck",
  }, sJiraInstance));
  });
}

export async function createJiraIssueV3(oOptions = {}) {
  return _dbgWrap('createJiraIssueV3', [oOptions], async function() {
  const jiraInstance = normalizeJiraInstance(oOptions);
  const projectKey = pickJiraValue(oOptions.projectKey, oOptions.project, oOptions.key);
  const issueTypeIds = pickJiraValue(oOptions.issueTypeIds, oOptions.issueTypeId, oOptions.issuetypeIds);
  const item = normalizeJiraIssuePayload(oOptions);
  return execJiraOp("CreateIssue_V3", {
    "X-Request-Jirainstance": jiraInstance,
    projectKey,
    issueTypeIds: normalizeJiraList(issueTypeIds),
    item,
  });
  });
}

export async function editJiraIssueV2(sIssueIdOrKey, oOptions = {}) {
  return _dbgWrap('editJiraIssueV2', [sIssueIdOrKey, oOptions], async function() {
  let jiraInstance = normalizeJiraInstance(oOptions);
  let notifyUsers = oOptions.notifyUsers;
  let overrideScreenSecurity = oOptions.overrideScreenSecurity;
  let overrideEditableFlag = oOptions.overrideEditableFlag;
  let body = normalizeJiraEditBody(oOptions);

  if (isJiraObject(sIssueIdOrKey)) {
    jiraInstance = normalizeJiraInstance(sIssueIdOrKey, jiraInstance);
    notifyUsers = pickJiraValue(sIssueIdOrKey.notifyUsers, notifyUsers);
    overrideScreenSecurity = pickJiraValue(sIssueIdOrKey.overrideScreenSecurity, overrideScreenSecurity);
    overrideEditableFlag = pickJiraValue(sIssueIdOrKey.overrideEditableFlag, overrideEditableFlag);
    body = normalizeJiraEditBody(sIssueIdOrKey);
    sIssueIdOrKey = pickJiraValue(sIssueIdOrKey.issueIdOrKey, sIssueIdOrKey.issueKey, sIssueIdOrKey.id, sIssueIdOrKey.key);
  }

  return execJiraOp("EditIssue_V2", {
    "X-Request-Jirainstance": jiraInstance,
    issueIdOrKey: sIssueIdOrKey,
    notifyUsers,
    overrideScreenSecurity,
    overrideEditableFlag,
    body: normalizeJiraEditBody({ body }),
  });
  });
}

export async function getCurrentJiraUser({ jiraInstance, expand } = {}) {
  return _dbgWrap('getCurrentJiraUser', [{ jiraInstance, expand }], async function() {
  jiraInstance = normalizeJiraInstance({ jiraInstance });
  return execJiraOp("GetCurrentUser", {
    "X-Request-Jirainstance": jiraInstance,
    expand: normalizeJiraList(expand),
  });
  });
}

export async function getJiraIssueByKey(sIssueKey, sJiraInstance) {
  return _dbgWrap('getJiraIssueByKey', [sIssueKey, sJiraInstance], async function() {
  if (isJiraObject(sIssueKey)) {
    sJiraInstance = normalizeJiraInstance(sIssueKey, sJiraInstance);
    sIssueKey = pickJiraValue(sIssueKey.issueKey, sIssueKey.issueIdOrKey, sIssueKey.id, sIssueKey.key);
  } else if (isJiraObject(sJiraInstance)) {
    sJiraInstance = normalizeJiraInstance(sJiraInstance, sJiraInstance);
  }

  const sOperationName = sJiraInstance ? "GetIssue_V2" : "GetIssue";
  return execJiraOp(sOperationName, withJiraInstance({
    issueKey: sIssueKey,
  }, sJiraInstance));
  });
}

export async function listJiraFilters(sJiraInstance) {
  return _dbgWrap('listJiraFilters', [sJiraInstance], async function() {
  const sInstance = normalizeJiraInstance(sJiraInstance);
  const sOperationName = sInstance ? "ListFilters_V2" : "ListFilters";
  return execJiraOp(sOperationName, withJiraInstance({}, sInstance));
  });
}

export async function listJiraIssues({ jiraInstance, jql, fields, expand } = {}) {
  return _dbgWrap('listJiraIssues', [{ jiraInstance, jql, fields, expand }], async function() {
  return execJiraOp("ListIssues", {
    "X-Request-Jirainstance": jiraInstance,
    jql,
    fields: normalizeJiraList(fields),
    expand: normalizeJiraList(expand),
  });
  });
}

export async function listJiraProjects(oOptions) {
  return _dbgWrap('listJiraProjects', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  return execJiraOp(sJiraInstance ? "ListProjects_V3" : "ListProjects_V2", withJiraInstance({}, sJiraInstance));
  });
}

export async function getJiraTask(sTaskId, sJiraInstance) {
  return _dbgWrap('getJiraTask', [sTaskId, sJiraInstance], async function() {
  if (isJiraObject(sTaskId)) {
    sJiraInstance = normalizeJiraInstance(sTaskId, sJiraInstance);
    sTaskId = pickJiraValue(sTaskId.taskId, sTaskId.id);
  }

  const sOperationName = sJiraInstance ? "GetTask_V2" : "GetTask";
  return execJiraOp(sOperationName, withJiraInstance({
    taskId: sTaskId,
  }, sJiraInstance));
  });
}

export async function getJiraUser(sAccountId, oOptions = {}) {
  return _dbgWrap('getJiraUser', [sAccountId, oOptions], async function() {
  let jiraInstance = normalizeJiraInstance(oOptions);
  let expand = isJiraObject(oOptions) ? oOptions.expand : undefined;

  if (isJiraObject(sAccountId)) {
    jiraInstance = normalizeJiraInstance(sAccountId, jiraInstance);
    expand = pickJiraValue(sAccountId.expand, expand);
    sAccountId = pickJiraValue(sAccountId.accountId, sAccountId.userId, sAccountId.id);
  } else if (typeof oOptions === "string") {
    jiraInstance = oOptions;
  }

  const sOperationName = jiraInstance ? "GetUser_V2" : "GetUser";
  return execJiraOp(sOperationName, withJiraInstance({
    accountId: sAccountId,
    expand: normalizeJiraList(expand),
  }, jiraInstance));
  });
}

export async function editJiraIssue(sIssueIdOrKey, oOptions = {}) {
  return _dbgWrap('editJiraIssue', [sIssueIdOrKey, oOptions], async function() {
  if (isJiraObject(sIssueIdOrKey)) {
    oOptions = sIssueIdOrKey;
    sIssueIdOrKey = pickJiraValue(oOptions.issueIdOrKey, oOptions.issueKey, oOptions.id, oOptions.key);
  }

  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = sJiraInstance ? "EditIssue_V2" : "EditIssue";
  return execJiraOp(sOperationName, withJiraInstance({
    issueIdOrKey: sIssueIdOrKey,
    notifyUsers: oOptions.notifyUsers,
    overrideScreenSecurity: oOptions.overrideScreenSecurity,
    overrideEditableFlag: oOptions.overrideEditableFlag,
    body: normalizeJiraEditBody(oOptions),
  }, sJiraInstance));
  });
}

export async function createJiraIssue(oOptions = {}) {
  return _dbgWrap('createJiraIssue', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sProjectKey = pickJiraValue(oOptions.projectKey, oOptions.project, oOptions.key);
  const sIssueTypeIds = normalizeJiraList(pickJiraValue(oOptions.issueTypeIds, oOptions.issueTypeId, oOptions.issuetypeIds));
  const oPayload = normalizeJiraIssuePayload(oOptions);

  if (sJiraInstance) {
    return execJiraOp("CreateIssue_V3", withJiraInstance({
      projectKey: sProjectKey,
      issueTypeIds: sIssueTypeIds,
      item: oPayload,
    }, sJiraInstance));
  }

  if (sIssueTypeIds !== undefined) {
    return execJiraOp("CreateIssueV2", {
      projectKey: sProjectKey,
      issueTypeIds: sIssueTypeIds,
      item: oPayload,
    });
  }

  return execJiraOp("CreateIssue", {
    projectKey: sProjectKey,
    body: oPayload,
  });
  });
}

export async function updateJiraIssue(sIssueKey, oOptions = {}) {
  return _dbgWrap('updateJiraIssue', [sIssueKey, oOptions], async function() {
  if (isJiraObject(sIssueKey)) {
    oOptions = sIssueKey;
    sIssueKey = pickJiraValue(oOptions.issueKey, oOptions.issueIdOrKey, oOptions.id, oOptions.key);
  }

  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = sJiraInstance ? "UpdateIssue_V2" : "UpdateIssue";
  return execJiraOp(sOperationName, withJiraInstance({
    issueKey: sIssueKey,
    body: normalizeJiraIssuePayload(oOptions),
  }, sJiraInstance));
  });
}

export async function listJiraIssueTypes(oOptions = {}) {
  return _dbgWrap('listJiraIssueTypes', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = sJiraInstance ? "ListIssueTypes_V2" : "ListIssueTypes";
  return execJiraOp(sOperationName, withJiraInstance({
    projectKey: pickJiraValue(oOptions.projectKey, oOptions.project, oOptions.key),
  }, sJiraInstance));
  });
}

export async function listJiraIssueTypeFields(oOptions = {}) {
  return _dbgWrap('listJiraIssueTypeFields', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = sJiraInstance ? "ListIssueTypesFields_V2" : "ListIssueTypesFields";
  return execJiraOp(sOperationName, withJiraInstance({
    projectKey: pickJiraValue(oOptions.projectKey, oOptions.project, oOptions.key),
    issuetypeIds: normalizeJiraList(pickJiraValue(oOptions.issueTypeIds, oOptions.issueTypeId, oOptions.issuetypeIds)),
  }, sJiraInstance));
  });
}

export async function createJiraProject(oOptions = {}) {
  return _dbgWrap('createJiraProject', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = sJiraInstance ? "CreateProject_V2" : "CreateProject";
  const oParams = {};
  setJiraIfDefined(oParams, "Project", normalizeJiraProjectBody(oOptions));
  return execJiraOp(sOperationName, withJiraInstance(oParams, sJiraInstance));
  });
}

export async function updateJiraProject(sProjectIdOrKey, oOptions = {}) {
  return _dbgWrap('updateJiraProject', [sProjectIdOrKey, oOptions], async function() {
  if (isJiraObject(sProjectIdOrKey)) {
    oOptions = sProjectIdOrKey;
    sProjectIdOrKey = pickJiraValue(oOptions.projectIdOrKey, oOptions.projectKey, oOptions.projectId, oOptions.id, oOptions.key);
  }

  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = sJiraInstance ? "UpdateProject_V2" : "UpdateProject";
  return execJiraOp(sOperationName, withJiraInstance({
    projectIdOrKey: sProjectIdOrKey,
    body: normalizeJiraProjectBody(oOptions),
  }, sJiraInstance));
  });
}

export async function deleteJiraProject(sProjectIdOrKey, oOptions = {}) {
  return _dbgWrap('deleteJiraProject', [sProjectIdOrKey, oOptions], async function() {
  if (isJiraObject(sProjectIdOrKey)) {
    oOptions = sProjectIdOrKey;
    sProjectIdOrKey = pickJiraValue(oOptions.projectIdOrKey, oOptions.projectKey, oOptions.projectId, oOptions.id, oOptions.key);
  }

  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = sJiraInstance ? "DeleteProject_V2" : "DeleteProject";
  return execJiraOp(sOperationName, withJiraInstance({
    projectIdOrKey: sProjectIdOrKey,
    enableUndo: oOptions.enableUndo,
  }, sJiraInstance));
  });
}

export async function listJiraProjectCategories(oOptions) {
  return _dbgWrap('listJiraProjectCategories', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  return execJiraOp(sJiraInstance ? "GetAllProjectCategories_V2" : "GetAllProjectCategories", withJiraInstance({}, sJiraInstance));
  });
}

export async function createJiraProjectCategory(oOptions = {}) {
  return _dbgWrap('createJiraProjectCategory', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  return execJiraOp(sJiraInstance ? "CreateProjectCategory_V2" : "CreateProjectCategory", withJiraInstance({
    body: normalizeJiraProjectCategoryBody(oOptions),
  }, sJiraInstance));
  });
}

export async function removeJiraProjectCategory(iId, oOptions) {
  return _dbgWrap('removeJiraProjectCategory', [iId, oOptions], async function() {
  if (isJiraObject(iId)) {
    oOptions = iId;
    iId = pickJiraValue(oOptions.id, oOptions.categoryId);
  }

  oOptions = isJiraObject(oOptions) ? oOptions : {};
  const sJiraInstance = normalizeJiraInstance(oOptions);
  return execJiraOp(sJiraInstance ? "RemoveProjectCategory_V2" : "RemoveProjectCategory", withJiraInstance({
    id: iId,
  }, sJiraInstance));
  });
}

export async function listJiraStatuses(oOptions = {}) {
  return _dbgWrap('listJiraStatuses', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = sJiraInstance ? "ListStatuses_V2" : "ListStatuses";
  return execJiraOp(sOperationName, withJiraInstance({
    projectId: pickJiraValue(oOptions.projectId, oOptions.project, oOptions.id),
    issueType: pickJiraValue(oOptions.issueType, oOptions.issueTypeId),
  }, sJiraInstance));
  });
}

export async function listJiraProjectUsers(oOptions = {}) {
  return _dbgWrap('listJiraProjectUsers', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = sJiraInstance ? "ListProjectUsers_V2" : "ListProjectUsers";
  return execJiraOp(sOperationName, withJiraInstance({
    projectKey: pickJiraValue(oOptions.projectKey, oOptions.project, oOptions.key),
  }, sJiraInstance));
  });
}

export async function listJiraAssignableUsers(oOptions = {}) {
  return _dbgWrap('listJiraAssignableUsers', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = sJiraInstance ? "ListAssignableUsers_V2" : "ListAssignableUsers";
  return execJiraOp(sOperationName, withJiraInstance({
    projectKey: pickJiraValue(oOptions.projectKey, oOptions.project, oOptions.key),
  }, sJiraInstance));
  });
}

export async function listJiraPriorityTypes(oOptions) {
  return _dbgWrap('listJiraPriorityTypes', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  return execJiraOp(sJiraInstance ? "ListPriorityTypes_V2" : "ListPriorityTypes", withJiraInstance({}, sJiraInstance));
  });
}

export async function listJiraResources() {
  return _dbgWrap('listJiraResources', [], async function() {
  return execJiraOp("ListResources", {});
  });
}

export async function listJiraIssuesDatacenter(oOptions = {}) {
  return _dbgWrap('listJiraIssuesDatacenter', [oOptions], async function() {
  return execJiraOp("ListIssues_Datacenter", withJiraInstance({}, normalizeJiraInstance(oOptions)));
  });
}

export async function listJiraTransitions(sIssueIdOrKey, oOptions = {}) {
  return _dbgWrap('listJiraTransitions', [sIssueIdOrKey, oOptions], async function() {
  if (isJiraObject(sIssueIdOrKey)) {
    oOptions = sIssueIdOrKey;
    sIssueIdOrKey = pickJiraValue(oOptions.issueIdOrKey, oOptions.issueKey, oOptions.id, oOptions.key);
  }

  return execJiraOp("ListTransitions", withJiraInstance({
    issueIdOrKey: sIssueIdOrKey,
  }, normalizeJiraInstance(oOptions)));
  });
}

export async function transitionJiraIssue(sIssueIdOrKey, oOptions = {}) {
  return _dbgWrap('transitionJiraIssue', [sIssueIdOrKey, oOptions], async function() {
  if (isJiraObject(sIssueIdOrKey)) {
    oOptions = sIssueIdOrKey;
    sIssueIdOrKey = pickJiraValue(oOptions.issueIdOrKey, oOptions.issueKey, oOptions.id, oOptions.key);
  }

  return execJiraOp("UpdateTransition", withJiraInstance({
    issueIdOrKey: sIssueIdOrKey,
    body: normalizeJiraTransitionBody(oOptions),
  }, normalizeJiraInstance(oOptions)));
  });
}

export async function onNewJiraIssue(oOptions = {}) {
  return _dbgWrap('onNewJiraIssue', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = oOptions.datacenter ? "OnNewIssue_Datacenter" : (sJiraInstance ? "OnNewIssue_V2" : "OnNewIssue");
  return execJiraOp(sOperationName, withJiraInstance({
    projectKey: pickJiraValue(oOptions.projectKey, oOptions.project, oOptions.key),
  }, sJiraInstance));
  });
}

export async function onClosedJiraIssue(oOptions = {}) {
  return _dbgWrap('onClosedJiraIssue', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = oOptions.datacenter ? "OnCloseIssue_Datacenter" : (sJiraInstance ? "OnCloseIssue_V2" : "OnCloseIssue");
  return execJiraOp(sOperationName, withJiraInstance({
    projectKey: pickJiraValue(oOptions.projectKey, oOptions.project, oOptions.key),
  }, sJiraInstance));
  });
}

export async function onUpdatedJiraIssue(oOptions = {}) {
  return _dbgWrap('onUpdatedJiraIssue', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = oOptions.datacenter ? "OnUpdateIssue_Datacenter" : (sJiraInstance ? "OnUpdateIssue_V2" : "OnUpdateIssue");
  return execJiraOp(sOperationName, withJiraInstance({
    projectKey: pickJiraValue(oOptions.projectKey, oOptions.project, oOptions.key),
  }, sJiraInstance));
  });
}

export async function onNewJiraIssueFromJql(oOptions = {}) {
  return _dbgWrap('onNewJiraIssueFromJql', [oOptions], async function() {
  const sJiraInstance = normalizeJiraInstance(oOptions);
  const sOperationName = oOptions.datacenter ? "OnNewIssueJQL_Datacenter" : (sJiraInstance ? "OnNewIssueJQL_V2" : "OnNewIssueJQL");
  return execJiraOp(sOperationName, withJiraInstance({
    jql: pickJiraValue(oOptions.jql, oOptions.query),
  }, sJiraInstance));
  });
}

export async function manageJiraIssues(queryRequest, sessionId) {
  return _dbgWrap('manageJiraIssues', [queryRequest, sessionId], async function() {
  if (isJiraObject(queryRequest) && sessionId === undefined && (Object.prototype.hasOwnProperty.call(queryRequest, "queryRequest") || Object.prototype.hasOwnProperty.call(queryRequest, "sessionId"))) {
    sessionId = queryRequest.sessionId;
    queryRequest = pickJiraValue(queryRequest.queryRequest, queryRequest.body, queryRequest);
  }

  return execJiraOp("mcp_JiraIssueManagement", {
    queryRequest,
    sessionId,
  });
  });
}
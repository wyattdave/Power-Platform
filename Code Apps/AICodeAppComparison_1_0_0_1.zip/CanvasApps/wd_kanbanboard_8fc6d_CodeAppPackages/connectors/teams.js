// ────────────────────────────────────────────────────────────────────────────
// ────────────────────────────────── Teams ───────────────────────────────────
// ────────────────────────────────────────────────────────────────────────────
import { getClient } from "../power-apps-data.js";
import {_dbgWrap  } from "../codeapp.js";
const TEAMS_DATA_SOURCE_CANDIDATES = ["teams", "Teams", "microsoftteams", "MicrosoftTeams"];
const TEAMS_APIS = {
  GetAllTeams: {
    path: "/{connectionId}/GetAllTeams",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
    ],
  },
  GetChannelsForGroup: {
    path: "/{connectionId}/GetChannelsForGroup",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "groupId", in: "query", required: true },
    ],
  },
  GetTeam: {
    path: "/{connectionId}/GetTeam",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "teamId", in: "query", required: true },
    ],
  },
  GetChannel: {
    path: "/{connectionId}/GetChannel",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "groupId", in: "query", required: true },
      { name: "channelId", in: "query", required: true },
    ],
  },
  AddMemberToTeam: {
    path: "/{connectionId}/AddMemberToTeam",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "teamId", in: "query", required: true },
      { name: "body", in: "body", required: true },
    ],
  },
  AddMemberToChannel: {
    path: "/{connectionId}/AddMemberToChannel",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "groupId", in: "query", required: true },
      { name: "channelId", in: "query", required: true },
      { name: "body", in: "body", required: true },
    ],
  },
  AtMentionUser: {
    path: "/{connectionId}/AtMentionUser",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "userId", in: "query", required: true },
    ],
  },
  AtMentionTag: {
    path: "/{connectionId}/AtMentionTag",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "teamId", in: "query", required: true },
      { name: "tagId", in: "query", required: true },
    ],
  },
  ListChats: {
    path: "/{connectionId}/ListChats",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "$top", in: "query", required: false },
      { name: "$skip", in: "query", required: false },
    ],
  },
  ListMembers: {
    path: "/{connectionId}/ListMembers",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "groupId", in: "query", required: true },
      { name: "channelId", in: "query", required: false },
    ],
  },
  PostUserNotification: {
    path: "/{connectionId}/PostUserNotification",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "PostNotificationRequest", in: "body", required: true },
    ],
  },
  PostChannelNotification: {
    path: "/{connectionId}/PostChannelNotification",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "groupId", in: "query", required: true },
      { name: "PostNotificationRequest", in: "body", required: true },
    ],
  },
  PostCardToConversation: {
    path: "/{connectionId}/PostCardToConversation",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "poster", in: "query", required: true },
      { name: "location", in: "query", required: true },
      { name: "body", in: "body", required: true },
    ],
  },
  PostMessageToConversation: {
    path: "/{connectionId}/PostMessageToConversation",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "poster", in: "query", required: true },
      { name: "location", in: "query", required: true },
      { name: "body", in: "body", required: true },
    ],
  },
  HttpRequest: {
    path: "/{connectionId}/codeless/v1.0/httprequest",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
    ],
  },
};

async function execTeamsOp(operationName, parameters) {
  return execConnectorOpWithCandidates(TEAMS_DATA_SOURCE_CANDIDATES, TEAMS_APIS, "Microsoft Teams", operationName, parameters);
}

export async function callTeamsOperation(operationName, parameters = {}) {
  return _dbgWrap('callTeamsOperation', [operationName, parameters], async function() {
  return execTeamsOp(operationName, parameters);
  });
}

export async function sendTeamsGraphHttpRequest({ method = "GET", uri, headers, body } = {}) {
  return _dbgWrap('sendTeamsGraphHttpRequest', [{ method, uri, headers, body }], async function() {
  return execTeamsOp("HttpRequest", {
    method,
    uri,
    headers: headers || {},
    body: body || "",
  });
  });
}

export async function listTeams() {
  return _dbgWrap('listTeams', [], async function() {
  return execTeamsOp("GetAllTeams", {});
  });
}

export async function listChannels(sTeamId) {
  return _dbgWrap('listChannels', [sTeamId], async function() {
  return execTeamsOp("GetChannelsForGroup", {
    groupId: sTeamId,
  });
  });
}

export async function getTeam(sTeamId) {
  return _dbgWrap('getTeam', [sTeamId], async function() {
  return execTeamsOp("GetTeam", {
    teamId: sTeamId,
  });
  });
}

export async function getChannelDetails(sTeamId, sChannelId) {
  return _dbgWrap('getChannelDetails', [sTeamId, sChannelId], async function() {
  return execTeamsOp("GetChannel", {
    groupId: sTeamId,
    channelId: sChannelId,
  });
  });
}

export async function addMemberToTeam(sTeamId, body) {
  return _dbgWrap('addMemberToTeam', [sTeamId, body], async function() {
  return execTeamsOp("AddMemberToTeam", {
    teamId: sTeamId,
    body,
  });
  });
}

export async function addMemberToChannel(sTeamId, sChannelId, body) {
  return _dbgWrap('addMemberToChannel', [sTeamId, sChannelId, body], async function() {
  return execTeamsOp("AddMemberToChannel", {
    groupId: sTeamId,
    channelId: sChannelId,
    body,
  });
  });
}

export async function getUserMentionToken(sUserId) {
  return _dbgWrap('getUserMentionToken', [sUserId], async function() {
  return execTeamsOp("AtMentionUser", {
    userId: sUserId,
  });
  });
}

export async function getTeamTagMentionToken(sTeamId, sTagId) {
  return _dbgWrap('getTeamTagMentionToken', [sTeamId, sTagId], async function() {
  return execTeamsOp("AtMentionTag", {
    teamId: sTeamId,
    tagId: sTagId,
  });
  });
}

export async function listChats({ top, skip } = {}) {
  return _dbgWrap('listChats', [{ top, skip }], async function() {
  return execTeamsOp("ListChats", {
    $top: top,
    $skip: skip,
  });
  });
}

export async function listMembers(sTeamId, sChannelId) {
  return _dbgWrap('listMembers', [sTeamId, sChannelId], async function() {
  return execTeamsOp("ListMembers", {
    groupId: sTeamId,
    channelId: sChannelId,
  });
  });
}

export async function postFeedNotification({ groupId, body } = {}) {
  return _dbgWrap('postFeedNotification', [{ groupId, body }], async function() {
  if (groupId) {
    return execTeamsOp("PostChannelNotification", {
      groupId,
      PostNotificationRequest: body,
    });
  }

  return execTeamsOp("PostUserNotification", {
    PostNotificationRequest: body,
  });
  });
}

export async function postCardInChatOrChannel({ poster = "Flow bot", location, body } = {}) {
  return _dbgWrap('postCardInChatOrChannel', [{ poster, location, body }], async function() {
  return execTeamsOp("PostCardToConversation", {
    poster,
    location,
    body,
  });
  });
}

export async function postMessageInChatOrChannel({ poster = "Flow bot", location, body } = {}) {
  return _dbgWrap('postMessageInChatOrChannel', [{ poster, location, body }], async function() {
  return execTeamsOp("PostMessageToConversation", {
    poster,
    location,
    body,
  });
  });
}


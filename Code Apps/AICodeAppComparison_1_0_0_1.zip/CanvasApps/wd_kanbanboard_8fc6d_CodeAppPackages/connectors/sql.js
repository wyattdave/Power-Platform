// ────────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────── SQL ────────────────────────────────────
// ────────────────────────────────────────────────────────────────────────────
import { getClient } from "../power-apps-data.js";
import {_dbgWrap  } from "../codeapp.js";
const SQL_DATA_SOURCE_CANDIDATES = ["sql", "Sql", "SQL"];
const SQL_APIS = {
  GetTables_V2: {
    path: "/GetTables_V2",
    method: "POST",
    parameters: [
      { name: "body", in: "body", required: true },
    ],
  },
  GetItems_V2: {
    path: "/GetItems_V2",
    method: "POST",
    parameters: [
      { name: "body", in: "body", required: true },
    ],
  },
  GetItem_V2: {
    path: "/GetItem_V2",
    method: "POST",
    parameters: [
      { name: "body", in: "body", required: true },
    ],
  },
  PostItem_V2: {
    path: "/PostItem_V2",
    method: "POST",
    parameters: [
      { name: "body", in: "body", required: true },
    ],
  },
  PatchItem_V2: {
    path: "/PatchItem_V2",
    method: "POST",
    parameters: [
      { name: "body", in: "body", required: true },
    ],
  },
  DeleteItem_V2: {
    path: "/DeleteItem_V2",
    method: "POST",
    parameters: [
      { name: "body", in: "body", required: true },
    ],
  },
  ExecutePassThroughNativeQuery_V2: {
    path: "/ExecutePassThroughNativeQuery_V2",
    method: "POST",
    parameters: [
      { name: "body", in: "body", required: true },
    ],
  },
  ExecuteProcedure_V2: {
    path: "/ExecuteProcedure_V2",
    method: "POST",
    parameters: [
      { name: "body", in: "body", required: true },
    ],
  },
};

async function execSqlOp(operationName, parameters) {
  return execConnectorOpWithCandidates(SQL_DATA_SOURCE_CANDIDATES, SQL_APIS, "SQL Server", operationName, parameters);
}

export async function callSqlOperation(operationName, parameters = {}) {
  return _dbgWrap('callSqlOperation', [operationName, parameters], async function() {
  return execSqlOp(operationName, parameters);
  });
}

export async function getSqlTables({ server = "default", database = "default" } = {}) {
  return _dbgWrap('getSqlTables', [{ server, database }], async function() {
  return execSqlOp("GetTables_V2", {
    body: { server, database },
  });
  });
}

export async function getSqlRows({ server = "default", database = "default", table, apply, filter, orderBy, skip, top, select } = {}) {
  return _dbgWrap('getSqlRows', [{ server, database, table, apply, filter, orderBy, skip, top, select }], async function() {
  const body = { server, database, table };
  if (apply) body.$apply = apply;
  if (filter) body.$filter = filter;
  if (orderBy) body.$orderby = orderBy;
  if (skip != null) body.$skip = skip;
  if (top != null) body.$top = top;
  if (select) body.$select = select;

  return execSqlOp("GetItems_V2", { body });
  });
}

export async function getSqlRow({ server = "default", database = "default", table, id } = {}) {
  return _dbgWrap('getSqlRow', [{ server, database, table, id }], async function() {
  return execSqlOp("GetItem_V2", {
    body: { server, database, table, id },
  });
  });
}

export async function insertSqlRow({ server = "default", database = "default", table, item } = {}) {
  return _dbgWrap('insertSqlRow', [{ server, database, table, item }], async function() {
  return execSqlOp("PostItem_V2", {
    body: { server, database, table, item },
  });
  });
}

export async function updateSqlRow({ server = "default", database = "default", table, id, item } = {}) {
  return _dbgWrap('updateSqlRow', [{ server, database, table, id, item }], async function() {
  return execSqlOp("PatchItem_V2", {
    body: { server, database, table, id, item },
  });
  });
}

export async function deleteSqlRow({ server = "default", database = "default", table, id } = {}) {
  return _dbgWrap('deleteSqlRow', [{ server, database, table, id }], async function() {
  return execSqlOp("DeleteItem_V2", {
    body: { server, database, table, id },
  });
  });
}

export async function executeSqlQuery({ server = "default", database = "default", query } = {}) {
  return _dbgWrap('executeSqlQuery', [{ server, database, query }], async function() {
  return execSqlOp("ExecutePassThroughNativeQuery_V2", {
    body: { server, database, query },
  });
  });
}

export async function executeSqlStoredProcedure({ server = "default", database = "default", procedure, parameters } = {}) {
  return _dbgWrap('executeSqlStoredProcedure', [{ server, database, procedure, parameters }], async function() {
  return execSqlOp("ExecuteProcedure_V2", {
    body: {
      server,
      database,
      procedure,
      parameters: parameters || {},
    },
  });
  });
}

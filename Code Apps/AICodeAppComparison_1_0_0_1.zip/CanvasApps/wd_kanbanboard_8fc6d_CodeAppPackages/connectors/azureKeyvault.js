// ────────────────────────────────────────────────────────────────────────────
// ───────────────────────────── Azure Key Vault ──────────────────────────────
// ────────────────────────────────────────────────────────────────────────────
import { getClient } from "../power-apps-data.js";
import {_dbgWrap  } from "../codeapp.js";
const KEY_VAULT_DATA_SOURCE_CANDIDATES = ["keyvault", "KeyVault", "azurekeyvault", "azureKeyVault", "AzureKeyVault"];
const KEY_VAULT_APIS = {
  ListKeys: {
    path: "/{connectionId}/keys",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
    ],
  },
  ListKeyVersions: {
    path: "/{connectionId}/keys/{keyName}/versions",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "keyName", in: "path", required: true },
    ],
  },
  GetKeyMetadata: {
    path: "/{connectionId}/keys/{keyName}/metadata",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "keyName", in: "path", required: true },
    ],
  },
  GetKeyVersionMetadata: {
    path: "/{connectionId}/keys/{keyName}/versions/{keyVersion}/metadata",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "keyName", in: "path", required: true },
      { name: "keyVersion", in: "path", required: true },
    ],
  },
  EncryptData: {
    path: "/{connectionId}/keys/{keyName}/encrypt",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "keyName", in: "path", required: true },
      { name: "operationInput", in: "body", required: true },
    ],
  },
  EncryptDataWithVersion: {
    path: "/{connectionId}/keys/{keyName}/versions/{keyVersion}/encrypt",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "keyName", in: "path", required: true },
      { name: "keyVersion", in: "path", required: true },
      { name: "operationInput", in: "body", required: true },
    ],
  },
  DecryptData: {
    path: "/{connectionId}/keys/{keyName}/decrypt",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "keyName", in: "path", required: true },
      { name: "operationInput", in: "body", required: true },
    ],
  },
  DecryptDataWithVersion: {
    path: "/{connectionId}/keys/{keyName}/versions/{keyVersion}/decrypt",
    method: "POST",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "keyName", in: "path", required: true },
      { name: "keyVersion", in: "path", required: true },
      { name: "operationInput", in: "body", required: true },
    ],
  },
  GetSecret: {
    path: "/{connectionId}/secrets/{secretName}/value",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "secretName", in: "path", required: true },
    ],
  },
  ListSecrets: {
    path: "/{connectionId}/secrets",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
    ],
  },
  ListSecretVersions: {
    path: "/{connectionId}/secrets/{secretName}/versions",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "secretName", in: "path", required: true },
    ],
  },
  GetSecretMetadata: {
    path: "/{connectionId}/secrets/{secretName}/metadata",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "secretName", in: "path", required: true },
    ],
  },
  GetSecretVersionMetadata: {
    path: "/{connectionId}/secrets/{secretName}/versions/{secretVersion}/metadata",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "secretName", in: "path", required: true },
      { name: "secretVersion", in: "path", required: true },
    ],
  },
  GetSecretVersion: {
    path: "/{connectionId}/secrets/{secretName}/versions/{secretVersion}/value",
    method: "GET",
    parameters: [
      { name: "connectionId", in: "path", required: true },
      { name: "secretName", in: "path", required: true },
      { name: "secretVersion", in: "path", required: true },
    ],
  },
};

function isKeyVaultObject(oValue) {
  return !!oValue && typeof oValue === "object" && !Array.isArray(oValue);
}

function pickKeyVaultValue() {
  for (let iIndex = 0; iIndex < arguments.length; iIndex += 1) {
    const oValue = arguments[iIndex];
    if (oValue !== undefined && oValue !== null) return oValue;
  }

  return undefined;
}

function setKeyVaultIfDefined(oTarget, sKey, oValue) {
  if (oValue !== undefined && oValue !== null) {
    oTarget[sKey] = oValue;
  }

  return oTarget;
}

function normalizeKeyVaultOperationInput(oInputOrOptions, sValueKey, oFallbackOptions) {
  const oSource = isKeyVaultObject(oInputOrOptions)
    ? (isKeyVaultObject(oInputOrOptions.operationInput)
      ? oInputOrOptions.operationInput
      : (isKeyVaultObject(oInputOrOptions.input)
        ? oInputOrOptions.input
        : (isKeyVaultObject(oInputOrOptions.body) ? oInputOrOptions.body : oInputOrOptions)))
    : (isKeyVaultObject(oFallbackOptions)
      ? (isKeyVaultObject(oFallbackOptions.operationInput)
        ? oFallbackOptions.operationInput
        : (isKeyVaultObject(oFallbackOptions.input)
          ? oFallbackOptions.input
          : (isKeyVaultObject(oFallbackOptions.body) ? oFallbackOptions.body : oFallbackOptions)))
      : {});

  const oPayload = {};
  const oFallbackSource = isKeyVaultObject(oFallbackOptions) ? oFallbackOptions : {};

  setKeyVaultIfDefined(oPayload, "algorithm", pickKeyVaultValue(
    oSource.algorithm,
    oSource.Algorithm,
    oSource.alg,
    oFallbackSource.algorithm,
    oFallbackSource.Algorithm,
    oFallbackSource.alg,
    "RSA-OAEP-256"
  ));

  if (typeof oInputOrOptions === "string") {
    setKeyVaultIfDefined(oPayload, sValueKey, oInputOrOptions);
    return oPayload;
  }

  if (sValueKey === "rawData") {
    setKeyVaultIfDefined(oPayload, sValueKey, pickKeyVaultValue(
      oSource.rawData,
      oSource.RawData,
      oSource.data,
      oSource.raw,
      oSource.plainText,
      oSource.plaintext,
      oSource.value,
      oFallbackSource.rawData,
      oFallbackSource.RawData,
      oFallbackSource.data,
      oFallbackSource.raw,
      oFallbackSource.plainText,
      oFallbackSource.plaintext,
      oFallbackSource.value
    ));
  } else {
    setKeyVaultIfDefined(oPayload, sValueKey, pickKeyVaultValue(
      oSource.encryptedData,
      oSource.EncryptedData,
      oSource.cipherText,
      oSource.ciphertext,
      oSource.data,
      oSource.value,
      oFallbackSource.encryptedData,
      oFallbackSource.EncryptedData,
      oFallbackSource.cipherText,
      oFallbackSource.ciphertext,
      oFallbackSource.data,
      oFallbackSource.value
    ));
  }

  return oPayload;
}

async function execKeyVaultOp(operationName, parameters) {
  return execConnectorOpWithCandidates(KEY_VAULT_DATA_SOURCE_CANDIDATES, KEY_VAULT_APIS, "Azure Key Vault", operationName, parameters);
}

export async function callKeyVaultOperation(operationName, parameters = {}) {
  return _dbgWrap('callKeyVaultOperation', [operationName, parameters], async function() {
  return execKeyVaultOp(operationName, parameters);
  });
}

export async function listKeys(oOptions = {}) {
  return _dbgWrap('listKeys', [oOptions], async function() {
  if (!isKeyVaultObject(oOptions)) {
    oOptions = {};
  }

  return execKeyVaultOp("ListKeys", {});
  });
}

export async function listKeyVersions(sKeyName) {
  return _dbgWrap('listKeyVersions', [sKeyName], async function() {
  if (isKeyVaultObject(sKeyName)) {
    sKeyName = pickKeyVaultValue(sKeyName.keyName, sKeyName.name);
  }

  return execKeyVaultOp("ListKeyVersions", {
    keyName: sKeyName,
  });
  });
}

export async function getKeyMetadata(sKeyName) {
  return _dbgWrap('getKeyMetadata', [sKeyName], async function() {
  if (isKeyVaultObject(sKeyName)) {
    sKeyName = pickKeyVaultValue(sKeyName.keyName, sKeyName.name);
  }

  return execKeyVaultOp("GetKeyMetadata", {
    keyName: sKeyName,
  });
  });
}

export async function getKeyVersionMetadata(sKeyName, sKeyVersion) {
  return _dbgWrap('getKeyVersionMetadata', [sKeyName, sKeyVersion], async function() {
  if (isKeyVaultObject(sKeyName)) {
    sKeyVersion = pickKeyVaultValue(sKeyName.keyVersion, sKeyName.version);
    sKeyName = pickKeyVaultValue(sKeyName.keyName, sKeyName.name);
  } else if (isKeyVaultObject(sKeyVersion)) {
    sKeyVersion = pickKeyVaultValue(sKeyVersion.keyVersion, sKeyVersion.version);
  }

  return execKeyVaultOp("GetKeyVersionMetadata", {
    keyName: sKeyName,
    keyVersion: sKeyVersion,
  });
  });
}

export async function encryptData(sKeyName, oInputOrOptions) {
  return _dbgWrap('encryptData', [sKeyName, oInputOrOptions], async function() {
  let oOptions = isKeyVaultObject(oInputOrOptions) ? oInputOrOptions : {};

  if (isKeyVaultObject(sKeyName)) {
    oOptions = sKeyName;
    sKeyName = pickKeyVaultValue(oOptions.keyName, oOptions.name);
  }

  const sKeyVersion = pickKeyVaultValue(oOptions.keyVersion, oOptions.version);
  const sOperationName = sKeyVersion ? "EncryptDataWithVersion" : "EncryptData";
  const params = {
    keyName: sKeyName,
    operationInput: normalizeKeyVaultOperationInput(oInputOrOptions, "rawData", oOptions),
  };

  setKeyVaultIfDefined(params, "keyVersion", sKeyVersion);
  return execKeyVaultOp(sOperationName, params);
  });
}

export async function encryptDataWithVersion(sKeyName, sKeyVersion, oInputOrOptions) {
  return _dbgWrap('encryptDataWithVersion', [sKeyName, sKeyVersion, oInputOrOptions], async function() {
  let oOptions = isKeyVaultObject(oInputOrOptions) ? oInputOrOptions : {};

  if (isKeyVaultObject(sKeyName)) {
    oOptions = sKeyName;
    sKeyVersion = pickKeyVaultValue(oOptions.keyVersion, oOptions.version);
    sKeyName = pickKeyVaultValue(oOptions.keyName, oOptions.name);
  } else if (isKeyVaultObject(sKeyVersion)) {
    oOptions = sKeyVersion;
    sKeyVersion = pickKeyVaultValue(oOptions.keyVersion, oOptions.version);
  }

  return execKeyVaultOp("EncryptDataWithVersion", {
    keyName: sKeyName,
    keyVersion: sKeyVersion,
    operationInput: normalizeKeyVaultOperationInput(oInputOrOptions, "rawData", oOptions),
  });
  });
}

export async function decryptData(sKeyName, oInputOrOptions) {
  return _dbgWrap('decryptData', [sKeyName, oInputOrOptions], async function() {
  let oOptions = isKeyVaultObject(oInputOrOptions) ? oInputOrOptions : {};

  if (isKeyVaultObject(sKeyName)) {
    oOptions = sKeyName;
    sKeyName = pickKeyVaultValue(oOptions.keyName, oOptions.name);
  }

  const sKeyVersion = pickKeyVaultValue(oOptions.keyVersion, oOptions.version);
  const sOperationName = sKeyVersion ? "DecryptDataWithVersion" : "DecryptData";
  const params = {
    keyName: sKeyName,
    operationInput: normalizeKeyVaultOperationInput(oInputOrOptions, "encryptedData", oOptions),
  };

  setKeyVaultIfDefined(params, "keyVersion", sKeyVersion);
  return execKeyVaultOp(sOperationName, params);
  });
}

export async function decryptDataWithVersion(sKeyName, sKeyVersion, oInputOrOptions) {
  return _dbgWrap('decryptDataWithVersion', [sKeyName, sKeyVersion, oInputOrOptions], async function() {
  let oOptions = isKeyVaultObject(oInputOrOptions) ? oInputOrOptions : {};

  if (isKeyVaultObject(sKeyName)) {
    oOptions = sKeyName;
    sKeyVersion = pickKeyVaultValue(oOptions.keyVersion, oOptions.version);
    sKeyName = pickKeyVaultValue(oOptions.keyName, oOptions.name);
  } else if (isKeyVaultObject(sKeyVersion)) {
    oOptions = sKeyVersion;
    sKeyVersion = pickKeyVaultValue(oOptions.keyVersion, oOptions.version);
  }

  return execKeyVaultOp("DecryptDataWithVersion", {
    keyName: sKeyName,
    keyVersion: sKeyVersion,
    operationInput: normalizeKeyVaultOperationInput(oInputOrOptions, "encryptedData", oOptions),
  });
  });
}

export async function getSecret(sSecretName, sApiVersion) {
  return _dbgWrap('getSecret', [sSecretName, sApiVersion], async function() {
  if (isKeyVaultObject(sSecretName)) {
    sApiVersion = pickKeyVaultValue(sSecretName.apiVersion, sSecretName.ApiVersion);
    sSecretName = pickKeyVaultValue(sSecretName.secretName, sSecretName.name);
  } else if (isKeyVaultObject(sApiVersion)) {
    sSecretName = pickKeyVaultValue(sSecretName, sApiVersion.secretName, sApiVersion.name);
  }

  return execKeyVaultOp("GetSecret", {
    secretName: sSecretName,
  });
  });
}

export async function listSecrets(oOptions = {}) {
  return _dbgWrap('listSecrets', [oOptions], async function() {
  if (!isKeyVaultObject(oOptions)) {
    oOptions = {};
  }

  return execKeyVaultOp("ListSecrets", {});
  });
}

export async function listSecretVersions(sSecretName, sApiVersion) {
  return _dbgWrap('listSecretVersions', [sSecretName, sApiVersion], async function() {
  if (isKeyVaultObject(sSecretName)) {
    sApiVersion = pickKeyVaultValue(sSecretName.apiVersion, sSecretName.ApiVersion);
    sSecretName = pickKeyVaultValue(sSecretName.secretName, sSecretName.name);
  } else if (isKeyVaultObject(sApiVersion)) {
    sSecretName = pickKeyVaultValue(sSecretName, sApiVersion.secretName, sApiVersion.name);
  }

  return execKeyVaultOp("ListSecretVersions", {
    secretName: sSecretName,
  });
  });
}

export async function getSecretMetadata(sSecretName, sApiVersion) {
  return _dbgWrap('getSecretMetadata', [sSecretName, sApiVersion], async function() {
  if (isKeyVaultObject(sSecretName)) {
    sApiVersion = pickKeyVaultValue(sSecretName.apiVersion, sSecretName.ApiVersion);
    sSecretName = pickKeyVaultValue(sSecretName.secretName, sSecretName.name);
  } else if (isKeyVaultObject(sApiVersion)) {
    sSecretName = pickKeyVaultValue(sSecretName, sApiVersion.secretName, sApiVersion.name);
  }

  return execKeyVaultOp("GetSecretMetadata", {
    secretName: sSecretName,
  });
  });
}

export async function getSecretVersionMetadata(sSecretName, sSecretVersion, sApiVersion) {
  return _dbgWrap('getSecretVersionMetadata', [sSecretName, sSecretVersion, sApiVersion], async function() {
  if (isKeyVaultObject(sSecretName)) {
    sApiVersion = pickKeyVaultValue(sSecretName.apiVersion, sSecretName.ApiVersion);
    sSecretVersion = pickKeyVaultValue(sSecretName.secretVersion, sSecretName.version);
    sSecretName = pickKeyVaultValue(sSecretName.secretName, sSecretName.name);
  } else if (isKeyVaultObject(sSecretVersion)) {
    sApiVersion = pickKeyVaultValue(sSecretVersion.apiVersion, sSecretVersion.ApiVersion);
    sSecretVersion = pickKeyVaultValue(sSecretVersion.secretVersion, sSecretVersion.version);
  } else if (isKeyVaultObject(sApiVersion)) {
    sSecretName = pickKeyVaultValue(sSecretName, sApiVersion.secretName, sApiVersion.name);
    sSecretVersion = pickKeyVaultValue(sSecretVersion, sApiVersion.secretVersion, sApiVersion.version);
  }

  return execKeyVaultOp("GetSecretVersionMetadata", {
    secretName: sSecretName,
    secretVersion: sSecretVersion,
  });
  });
}

export async function getSecretVersion(sSecretName, sSecretVersion, sApiVersion) {
  return _dbgWrap('getSecretVersion', [sSecretName, sSecretVersion, sApiVersion], async function() {
  if (isKeyVaultObject(sSecretName)) {
    sApiVersion = pickKeyVaultValue(sSecretName.apiVersion, sSecretName.ApiVersion);
    sSecretVersion = pickKeyVaultValue(sSecretName.secretVersion, sSecretName.version);
    sSecretName = pickKeyVaultValue(sSecretName.secretName, sSecretName.name);
  } else if (isKeyVaultObject(sSecretVersion)) {
    sApiVersion = pickKeyVaultValue(sSecretVersion.apiVersion, sSecretVersion.ApiVersion);
    sSecretVersion = pickKeyVaultValue(sSecretVersion.secretVersion, sSecretVersion.version);
  } else if (isKeyVaultObject(sApiVersion)) {
    sSecretName = pickKeyVaultValue(sSecretName, sApiVersion.secretName, sApiVersion.name);
    sSecretVersion = pickKeyVaultValue(sSecretVersion, sApiVersion.secretVersion, sApiVersion.version);
  }

  return execKeyVaultOp("GetSecretVersion", {
    secretName: sSecretName,
    secretVersion: sSecretVersion,
  });
  });
}
import { enableDebugger } from "./codeapp.js";

enableDebugger();

import {
  initDataSources,
  createItem,
  listItems,
  updateItem,
  deleteItem,
} from './codeapp.js';

// ────────────────────────────────────────────────────────────────────────────
// ── Table Configuration (Dataverse Task table) ─────────────────────────────
// Uses only standard Dataverse Task columns.
// ────────────────────────────────────────────────────────────────────────────
const TABLE_NAME  = 'tasks';
const PRIMARY_KEY = 'activityid';
const COL_TITLE   = 'subject';
const COL_DESC    = 'description';
const COL_STATUS  = 'statuscode';
const COL_STATE   = 'statecode';

const STATUS_OPTIONS = [
  { board: 'Backlog',         code: 7, state: 0, dataverseLabel: 'Deferred',                color: '#555'     },
  { board: 'Ready',           code: 2, state: 0, dataverseLabel: 'Not Started',             color: '#22d3ee'  },
  { board: 'In-progress',     code: 3, state: 0, dataverseLabel: 'In Progress',             color: '#fb923c'  },
  { board: 'Awaiting Review', code: 4, state: 0, dataverseLabel: 'Waiting on someone else', color: '#f472b6'  },
  { board: 'Complete',        code: 5, state: 1, dataverseLabel: 'Completed',               color: '#a3e635', isClosed: true },
];
const DEFAULT_BOARD_STATUS = 'Backlog';
const DEFAULT_STATUS_CODE = 7;
const STATUS_BY_CODE = new Map(STATUS_OPTIONS.map((status) => [status.code, status]));
const STATUS_BY_BOARD = new Map(STATUS_OPTIONS.map((status) => [status.board, status]));

// ── App state ──────────────────────────────────────────────────────────────
let tasks = [];
let searchTerm = '';
let editingTask = null;   // null = create mode, object = edit mode
let draggedId = null;

// ── DOM refs ───────────────────────────────────────────────────────────────
const $board      = document.getElementById('board');
const $overlay    = document.getElementById('overlay');
const $modalTitle = document.getElementById('modalTitle');
const $fTitle     = document.getElementById('fTitle');
const $fDesc      = document.getElementById('fDesc');
const $fStatus    = document.getElementById('fStatus');
const $btnSave    = document.getElementById('btnSave');
const $btnDelete  = document.getElementById('btnDelete');
const $btnCancel  = document.getElementById('btnCancel');
const $btnNew     = document.getElementById('btnNew');
const $modalClose = document.getElementById('modalClose');
const $search     = document.getElementById('search');
const $loading    = document.getElementById('loadingBar');
const $toast      = document.getElementById('toast');
const $total      = document.getElementById('totalCount');
const $active     = document.getElementById('activeCount');
const $done       = document.getElementById('doneCount');

function normalizeStatusCode(value) {
  const code = Number(value);
  return STATUS_BY_CODE.has(code) ? code : DEFAULT_STATUS_CODE;
}

function getStatusMeta(taskOrCode) {
  if (typeof taskOrCode === 'object') {
    const stateCode = Number(taskOrCode[COL_STATE]);
    const code = normalizeStatusCode(taskOrCode[COL_STATUS]);

    if (stateCode === 2) {
      return null;
    }
    if (STATUS_BY_CODE.has(code)) {
      return STATUS_BY_CODE.get(code);
    }
    if (stateCode === 1) {
      return STATUS_BY_BOARD.get('Complete');
    }
    return STATUS_BY_BOARD.get(DEFAULT_BOARD_STATUS);
  }

  const code = normalizeStatusCode(taskOrCode);
  return STATUS_BY_CODE.get(code) || STATUS_BY_CODE.get(DEFAULT_STATUS_CODE);
}

function buildStatusFields(statusCode) {
  const meta = getStatusMeta(statusCode);
  return {
    [COL_STATUS]: meta.code,
    [COL_STATE]: meta.state,
  };
}

function populateStatusOptions() {
  $fStatus.innerHTML = STATUS_OPTIONS.map((status) =>
    '<option value="' + escapeHtml(status.board) + '">' + escapeHtml(status.board) + '</option>'
  ).join('');
}

function setModalReadOnly(isReadOnly) {
  $fTitle.disabled = isReadOnly;
  $fDesc.disabled = isReadOnly;
  $fStatus.disabled = isReadOnly;
  $btnSave.disabled = isReadOnly;
  $btnSave.textContent = isReadOnly ? 'LOCKED' : (editingTask ? 'SAVE' : 'SUBMIT');
}

// ────────────────────────────────────────────────────────────────────────────
// ── Helpers ────────────────────────────────────────────────────────────────
// ────────────────────────────────────────────────────────────────────────────

function showLoading() { $loading.style.width = '60%'; }
function hideLoading() { $loading.style.width = '100%'; setTimeout(() => { $loading.style.width = '0'; }, 300); }

function toast(msg, isError) {
  $toast.textContent = msg;
  $toast.className = 'toast show' + (isError ? ' error' : '');
  setTimeout(() => { $toast.className = 'toast'; }, 2500);
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ────────────────────────────────────────────────────────────────────────────
// ── Render ─────────────────────────────────────────────────────────────────
// ────────────────────────────────────────────────────────────────────────────

function updateStats() {
  $total.textContent  = tasks.length;
  $active.textContent = tasks.filter(t => getStatusMeta(t)?.board === 'In-progress').length;
  $done.textContent   = tasks.filter(t => getStatusMeta(t)?.board === 'Complete').length;
}

function render() {
  $board.innerHTML = '';
  const lowerSearch = searchTerm.toLowerCase();

  STATUS_OPTIONS.forEach(status => {
    const col = document.createElement('div');
    col.className = 'column';

    const filtered = tasks.filter(t =>
      getStatusMeta(t)?.board === status.board &&
      (!lowerSearch || (t[COL_TITLE] || '').toLowerCase().includes(lowerSearch)
                    || (t[COL_DESC]  || '').toLowerCase().includes(lowerSearch))
    );

    // Column header
    const header = document.createElement('div');
      header.className = 'col-header';
      header.innerHTML =
        '<div class="col-status">' +
          '<div class="col-indicator" style="background:' + status.color + '"></div>' +
          '<span class="col-name">' + escapeHtml(status.board) + '</span>' +
        '</div>' +
        '<span class="col-count">' + filtered.length + '</span>';
    col.appendChild(header);

    // Column body (drop zone)
    const body = document.createElement('div');
    body.className = 'col-body';
    body.dataset.status = status.board;

    if (filtered.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-col';
      empty.textContent = 'Drop here';
      body.appendChild(empty);
    }

    filtered.forEach(t => {
      const id = t[PRIMARY_KEY];
      const taskStatus = getStatusMeta(t);
      const card = document.createElement('div');
      card.className = 'card';
      card.draggable = !taskStatus.isClosed;
      card.dataset.id = id;

      card.innerHTML =
        '<div class="card-title">' + escapeHtml(t[COL_TITLE]) + '</div>' +
        (t[COL_DESC] ? '<div class="card-desc">' + escapeHtml(t[COL_DESC]) + '</div>' : '') +
        '<div class="card-footer">' +
          '<div class="card-tags">' +
            '<span class="tag" style="background:' + taskStatus.color + '22;color:' + taskStatus.color + '">' + escapeHtml(taskStatus.board) + '</span>' +
          '</div>' +
        '</div>';

      // Click title to edit
      card.querySelector('.card-title').addEventListener('click', (e) => {
        e.stopPropagation();
        openEditModal(t);
      });

      // Drag start
      if (!taskStatus.isClosed) {
        card.addEventListener('dragstart', (e) => {
          draggedId = id;
          card.classList.add('dragging');
          e.dataTransfer.effectAllowed = 'move';
          e.dataTransfer.setData('text/plain', id);
        });
        card.addEventListener('dragend', () => {
          card.classList.remove('dragging');
          draggedId = null;
        });
      }

      body.appendChild(card);
    });

    // Drop zone events
    body.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      body.classList.add('drag-over');
    });
    body.addEventListener('dragleave', (e) => {
      if (!body.contains(e.relatedTarget)) {
        body.classList.remove('drag-over');
      }
    });
    body.addEventListener('drop', (e) => {
      e.preventDefault();
      body.classList.remove('drag-over');
      const droppedId = e.dataTransfer.getData('text/plain');
      const nextStatus = body.dataset.status || DEFAULT_BOARD_STATUS;
      const task = tasks.find(t => t[PRIMARY_KEY] === droppedId);
      if (task && !getStatusMeta(task).isClosed && getStatusMeta(task).board !== nextStatus) {
        changeStatus(task, nextStatus);
      }
    });

    col.appendChild(body);
    $board.appendChild(col);
  });

  updateStats();
}

// ────────────────────────────────────────────────────────────────────────────
// ── Dataverse CRUD ─────────────────────────────────────────────────────────
// ────────────────────────────────────────────────────────────────────────────

async function loadTasks() {
  showLoading();
  try {
    const result = await listItems(TABLE_NAME, PRIMARY_KEY, {
      filter: 'statecode ne 2',
      select: [PRIMARY_KEY, COL_TITLE, COL_DESC, COL_STATUS, COL_STATE],
      orderBy: ['createdon desc'],
    });
    tasks = result.entities || [];
    render();
  } catch (err) {
    console.error('loadTasks failed:', err);
    toast('Failed to load tasks: ' + err.message, true);
  } finally {
    hideLoading();
  }
}

async function createTask(title, desc, status) {
  showLoading();
  try {
    const record = {};
    record[COL_TITLE]  = title;
    record[COL_DESC]   = desc;
    Object.assign(record, buildStatusFields(status));
    await createItem(TABLE_NAME, PRIMARY_KEY, record);
    toast('Task created');
    await loadTasks();
  } catch (err) {
    console.error('createTask failed:', err);
    toast('Create failed: ' + err.message, true);
  } finally {
    hideLoading();
  }
}

async function editTask(id, changes) {
  showLoading();
  try {
    await updateItem(TABLE_NAME, PRIMARY_KEY, id, changes);
    toast('Task updated');
    await loadTasks();
  } catch (err) {
    console.error('editTask failed:', err);
    toast('Update failed: ' + err.message, true);
  } finally {
    hideLoading();
  }
}

async function removeTask(id) {
  showLoading();
  try {
    await deleteItem(TABLE_NAME, PRIMARY_KEY, id);
    toast('Task deleted');
    await loadTasks();
  } catch (err) {
    console.error('removeTask failed:', err);
    toast('Delete failed: ' + err.message, true);
  } finally {
    hideLoading();
  }
}

async function changeStatus(task, newStatus) {
  const id = task[PRIMARY_KEY];
  const previousFields = buildStatusFields(task[COL_STATUS]);
  Object.assign(task, buildStatusFields(STATUS_BY_BOARD.get(newStatus).code));
  render();
  try {
    const changes = buildStatusFields(STATUS_BY_BOARD.get(newStatus).code);
    await updateItem(TABLE_NAME, PRIMARY_KEY, id, changes);
    toast('Moved to ' + newStatus);
  } catch (err) {
    console.error('changeStatus failed:', err);
    toast('Status update failed: ' + err.message, true);
    Object.assign(task, previousFields);
    await loadTasks();
  }
}

// ────────────────────────────────────────────────────────────────────────────
// ── Modal ──────────────────────────────────────────────────────────────────
// ────────────────────────────────────────────────────────────────────────────

function openCreateModal() {
  editingTask = null;
  $modalTitle.textContent = '// NEW TASK';
  $fTitle.value = '';
  $fDesc.value = '';
  $fStatus.value = DEFAULT_BOARD_STATUS;
  $btnDelete.style.display = 'none';
  setModalReadOnly(false);
  $overlay.classList.add('open');
  $fTitle.focus();
}

function openEditModal(task) {
  editingTask = task;
  const status = getStatusMeta(task);
  const isClosed = !!status.isClosed;
  $modalTitle.textContent = isClosed ? '// CLOSED TASK' : '// EDIT TASK';
  $fTitle.value  = task[COL_TITLE]  || '';
  $fDesc.value   = task[COL_DESC]   || '';
  $fStatus.value = status.board;
  $btnDelete.style.display = 'inline-block';
  setModalReadOnly(isClosed);
  $overlay.classList.add('open');
  (isClosed ? $btnDelete : $fTitle).focus();
}

function closeModal() {
  $overlay.classList.remove('open');
  editingTask = null;
  setModalReadOnly(false);
}

async function handleSave() {
  if ($btnSave.disabled) return;
  const title = $fTitle.value.trim();
  if (!title) { $fTitle.style.borderColor = '#ef4444'; return; }
  $fTitle.style.borderColor = '';
  const statusCode = STATUS_BY_BOARD.get($fStatus.value || DEFAULT_BOARD_STATUS)?.code || DEFAULT_STATUS_CODE;
  const currentTask = editingTask;

  closeModal();

  if (currentTask) {
    const changes = {};
    changes[COL_TITLE]  = title;
    changes[COL_DESC]   = $fDesc.value.trim();
    Object.assign(changes, buildStatusFields(statusCode));
    await editTask(currentTask[PRIMARY_KEY], changes);
  } else {
    await createTask(title, $fDesc.value.trim(), statusCode);
  }
}

async function handleDelete() {
  if (!editingTask) return;
  const id = editingTask[PRIMARY_KEY];
  closeModal();
  await removeTask(id);
}

// ────────────────────────────────────────────────────────────────────────────
// ── Events ─────────────────────────────────────────────────────────────────
// ────────────────────────────────────────────────────────────────────────────

$btnNew.addEventListener('click', openCreateModal);
$btnCancel.addEventListener('click', closeModal);
$modalClose.addEventListener('click', closeModal);
$btnSave.addEventListener('click', handleSave);
$btnDelete.addEventListener('click', handleDelete);
$search.addEventListener('input', () => { searchTerm = $search.value; render(); });

$overlay.addEventListener('click', (e) => { if (e.target === $overlay) closeModal(); });

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && $overlay.classList.contains('open')) closeModal();
});

// ────────────────────────────────────────────────────────────────────────────
// ── Boot ───────────────────────────────────────────────────────────────────
// ────────────────────────────────────────────────────────────────────────────

function dsEntry(sPrimaryKey) {
  return { tableId: '', version: '', primaryKey: sPrimaryKey, dataSourceType: 'Dataverse', apis: {} };
}

async function boot() {
  populateStatusOptions();
  initDataSources({
    tasks: dsEntry(PRIMARY_KEY),
  });
  await loadTasks();
}

boot();

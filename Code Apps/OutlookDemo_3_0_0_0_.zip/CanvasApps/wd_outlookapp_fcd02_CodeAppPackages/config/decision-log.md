# Decision Log - Outlook App

## TODO
- [x] Theme/colour confirmation (user: Star Trek TNG)
- [x] Mockup offer (user declined, build directly)
- [x] Add Office 365 Outlook connection reference
- [x] Build LCARS UI in index.html
- [x] Wire inbox (last 10), view, compose, reply in index.js

## Custom Requirements
- Theme: Star Trek: The Next Generation - LCARS interface (black background, orange/lilac/violet/sky pill buttons, elbow frames, condensed uppercase type, stardates).
- Features: last 10 inbox emails, open/view, create email, reply (and reply all).

## Decisions
- Uses `office365outlook.js` helpers: `listEmails({top:10})` (GetEmailsV3), `getEmail` (GetEmailV2), `sendEmail` (SendEmailV2), `replyToEmail` (ReplyToV3).
- Email HTML rendered in a sandboxed `srcdoc` iframe (no scripts, no same-origin) to isolate untrusted content; all other text set via `textContent`; user-typed bodies HTML-escaped before sending.
- Reply mode locks To/Cc/Subject (connector ReplyToV3 determines recipients); "Reply all" toggles `ReplyAll`.
- No external fonts; condensed local font stack (Antonio/Oswald/Bahnschrift/Arial Narrow).
- Stardate display: 1000 units/year, 1987 = 41000.

## File Changes
- power.config.json: +12 / -2
- dist/index.html: +492 / -1
- dist/index.js: +250 / -7
- dist/config/decision-log.md: new

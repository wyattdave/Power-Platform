import { listEmails, getEmail, sendEmail, replyToEmail } from './connectors/office365outlook.js';

const $ = (sId) => document.getElementById(sId);

const oState = {
  aEmails: [],
  oCurrent: null,
  sMode: 'new' // 'new' | 'reply'
};

async function boot() {
  $('stardate').textContent = 'Stardate ' + getStardate(new Date());
  wireEvents();
  await loadInbox();
}

function wireEvents() {
  $('btnRefresh').addEventListener('click', loadInbox);
  $('btnCompose').addEventListener('click', () => openCompose('new'));
  $('btnReply').addEventListener('click', () => openCompose('reply', false));
  $('btnReplyAll').addEventListener('click', () => openCompose('reply', true));
  $('chipReply').addEventListener('click', () => openCompose('reply', false));
  $('chipReplyAll').addEventListener('click', () => openCompose('reply', true));
  $('btnCancel').addEventListener('click', closeCompose);
  $('composeForm').addEventListener('submit', onSend);
  $('fReplyAll').addEventListener('change', updateReplyAllPreview);
  $('composeOverlay').addEventListener('click', (e) => {
    if (e.target === $('composeOverlay')) closeCompose();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && $('composeOverlay').classList.contains('open')) closeCompose();
  });
}

// ---------- inbox ----------
async function loadInbox() {
  const eList = $('mailList');
  eList.innerHTML = '<li class="loading-bars"><span></span><span></span><span></span><span></span></li>';
  setStatus('Scanning subspace frequencies…');
  try {
    const oResult = await listEmails({ top: 10 });
    oState.aEmails = Array.isArray(oResult) ? oResult : (oResult && oResult.value) || [];
    renderList();
    setStatus(oState.aEmails.length + ' transmissions received');
  } catch (oErr) {
    eList.innerHTML = '';
    setStatus('Scan failed: ' + oErr.message, true);
  }
}

function renderList() {
  const eList = $('mailList');
  eList.innerHTML = '';
  if (!oState.aEmails.length) {
    const eLi = document.createElement('li');
    eLi.className = 'view-empty';
    eLi.textContent = 'No transmissions';
    eList.appendChild(eLi);
    return;
  }

  oState.aEmails.forEach((oMail, iIndex) => {
    const eLi = document.createElement('li');
    const eBtn = document.createElement('button');
    eBtn.type = 'button';
    eBtn.className = 'mail-item' + (oMail.isRead ? '' : ' unread');
    eBtn.style.animationDelay = (iIndex * 60) + 'ms';
    eBtn.dataset.id = oMail.id;

    const eText = document.createElement('div');
    eText.style.minWidth = '0';
    eText.append(
      makeDiv('mail-from', displayName(oMail.from)),
      makeDiv('mail-subject', oMail.subject || '(no subject)'),
      makeDiv('mail-preview', oMail.bodyPreview || '')
    );
    const eMeta = makeDiv('mail-meta', '');
    eMeta.append(
      makeSpan(formatDate(oMail.receivedDateTime)),
      makeSpan(oMail.hasAttachments ? 'Attachment' : (oMail.importance === 'high' ? 'Priority One' : ''))
    );
    eText.appendChild(eMeta);

    eBtn.appendChild(eText);
    eBtn.addEventListener('click', () => openEmail(oMail.id));
    eLi.appendChild(eBtn);
    eList.appendChild(eLi);
  });
}

// ---------- view ----------
async function openEmail(sId) {
  document.querySelectorAll('.mail-item').forEach((e) => e.classList.toggle('active', e.dataset.id === sId));
  const oListed = oState.aEmails.find((o) => o.id === sId);
  showEmail(oListed);
  setStatus('Decoding transmission…');
  try {
    const oFull = await getEmail(sId);
    if (oFull && oFull.id) {
      showEmail(Object.assign({}, oListed, oFull));
    }
    if (oListed) oListed.isRead = true;
    const eItem = document.querySelector('.mail-item.active');
    if (eItem) eItem.classList.remove('unread');
    setStatus('Transmission displayed');
  } catch (oErr) {
    setStatus('Could not decode full message: ' + oErr.message, true);
  }
}

function showEmail(oMail) {
  if (!oMail) return;
  oState.oCurrent = oMail;
  $('viewEmpty').hidden = true;
  $('viewContent').hidden = false;
  $('msgBody').hidden = false;
  $('msgSubject').textContent = oMail.subject || '(no subject)';
  $('msgFrom').textContent = oMail.from || '';
  $('msgTo').textContent = oMail.toRecipients || '';
  $('msgCc').textContent = oMail.ccRecipients || '';
  $('msgCc').hidden = $('msgCcLabel').hidden = !oMail.ccRecipients;
  $('msgDate').textContent = formatDate(oMail.receivedDateTime, true);

  // Rendered in a fully sandboxed iframe so email HTML/scripts cannot touch the app.
  const sBody = oMail.isHtml === false
    ? '<pre style="white-space:pre-wrap;font-family:Segoe UI,sans-serif">' + escapeHtml(oMail.body || '') + '</pre>'
    : (oMail.body || escapeHtml(oMail.bodyPreview || ''));
  $('msgBody').srcdoc = '<!doctype html><html><head><meta charset="utf-8"><base target="_blank">'
    + '<style>body{margin:16px;font-family:Segoe UI,sans-serif;font-size:14px;color:#1a1a1a;word-wrap:break-word}img{max-width:100%;height:auto}</style>'
    + '</head><body>' + sBody + '</body></html>';

  $('btnReply').disabled = false;
  $('btnReplyAll').disabled = false;
}

// ---------- compose / reply ----------
function openCompose(sMode, bReplyAll) {
  const oMail = oState.oCurrent;
  if (sMode === 'reply' && !oMail) return;
  oState.sMode = sMode;
  $('composeForm').reset();

  const bReply = sMode === 'reply';
  $('composeTitle').textContent = bReply ? 'Hailing Response' : 'New Transmission';
  $('fTo').readOnly = bReply;
  $('fCc').readOnly = bReply;
  $('fSubject').readOnly = bReply;
  $('fTo').required = !bReply;
  $('replyAllWrap').hidden = !bReply;

  if (bReply) {
    $('fTo').value = oMail.from || '';
    $('fCc').value = '';
    $('fSubject').value = /^re:/i.test(oMail.subject || '') ? oMail.subject : 'RE: ' + (oMail.subject || '');
    $('fReplyAll').checked = !!bReplyAll;
    updateReplyAllPreview();
  }

  $('composeOverlay').classList.add('open');
  (bReply ? $('fBody') : $('fTo')).focus();
}

function updateReplyAllPreview() {
  const oMail = oState.oCurrent;
  if (!oMail || oState.sMode !== 'reply') return;
  const bAll = $('fReplyAll').checked;
  $('fTo').value = bAll ? joinAddresses(oMail.from, oMail.toRecipients) : (oMail.from || '');
  $('fCc').value = bAll ? (oMail.ccRecipients || '') : '';
}

function closeCompose() {
  $('composeOverlay').classList.remove('open');
}

async function onSend(e) {
  e.preventDefault();
  const sBody = $('fBody').value.trim();
  if (!sBody) return;
  const sHtml = escapeHtml(sBody).replace(/\r?\n/g, '<br>');
  const eSend = $('btnSend');
  eSend.disabled = true;
  setStatus('Opening hailing frequencies…');

  try {
    if (oState.sMode === 'reply') {
      await replyToEmail(oState.oCurrent.id, { body: sHtml, replyAll: $('fReplyAll').checked });
      setStatus('Reply transmitted');
    } else {
      await sendEmail({
        to: $('fTo').value.trim(),
        cc: $('fCc').value.trim() || undefined,
        subject: $('fSubject').value.trim(),
        body: sHtml
      });
      setStatus('Transmission sent');
    }
    closeCompose();
  } catch (oErr) {
    setStatus('Transmission failed: ' + oErr.message, true);
  } finally {
    eSend.disabled = false;
  }
}

// ---------- helpers ----------
function setStatus(sText, bError) {
  const e = $('status');
  e.textContent = sText;
  e.classList.toggle('error', !!bError);
}

function makeDiv(sClass, sText) {
  const e = document.createElement('div');
  e.className = sClass;
  e.textContent = sText;
  return e;
}

function makeSpan(sText) {
  const e = document.createElement('span');
  e.textContent = sText;
  return e;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function displayName(sFrom) {
  if (!sFrom) return 'Unknown';
  return sFrom.split('@')[0].replace(/[._]/g, ' ');
}

function joinAddresses() {
  const aAll = Array.from(arguments).filter(Boolean).join(';').split(';').map((s) => s.trim()).filter(Boolean);
  return Array.from(new Set(aAll.map((s) => s.toLowerCase()))).join('; ');
}

function formatDate(sDate, bLong) {
  if (!sDate) return '';
  const d = new Date(sDate);
  return bLong
    ? d.toLocaleString() + ' · SD ' + getStardate(d)
    : d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
}

// TNG-style stardate: 1000 units per year, anchored to the 1987 premiere = 41000.
function getStardate(d) {
  const iYear = d.getFullYear();
  const iStart = new Date(iYear, 0, 1).getTime();
  const iEnd = new Date(iYear + 1, 0, 1).getTime();
  const nFrac = (d.getTime() - iStart) / (iEnd - iStart);
  return (41000 + (iYear - 1987) * 1000 + nFrac * 1000).toFixed(1);
}

boot();

/* ============================================
   Countries Explorer — index.js
   ============================================ */

// ---- State ----
let allCountries = [];
let activeIndex = -1;
let dropdownOpen = false;
let currentAbort = null;

// ---- DOM Refs ----
const searchInput = document.getElementById('searchInput');
const searchClear = document.getElementById('searchClear');
const dropdown = document.getElementById('dropdown');
const mainContent = document.getElementById('mainContent');

// ---- Boot ----
const boot = async () => {
  try {
    await loadCountryList();
    bindEvents();
  } catch (err) {
    console.error('Boot error:', err);
    showError('Failed to load country list. Please refresh.');
  }
};

// ---- Fetch All Country Names ----
const loadCountryList = async () => {
  const response = await fetch('https://restcountries.com/v3.1/all?fields=name,flags,cca2');
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const data = await response.json();
  allCountries = data
    .map(c => ({
      name: c.name.common,
      official: c.name.official,
      flag: c.flags?.emoji || getFlagEmoji(c.cca2),
      cca2: c.cca2,
    }))
    .sort((a, b) => a.name.localeCompare(b.name));
};

// ---- Flag Emoji from country code ----
const getFlagEmoji = (code) => {
  if (!code) return '🏳️';
  return [...code.toUpperCase()].map(c => String.fromCodePoint(0x1F1E6 + c.charCodeAt(0) - 65)).join('');
};

// ---- Event Binding ----
const bindEvents = () => {
  searchInput.addEventListener('input', onSearchInput);
  searchInput.addEventListener('focus', onSearchFocus);
  searchInput.addEventListener('keydown', onSearchKeydown);
  searchClear.addEventListener('click', onClearSearch);

  document.addEventListener('click', (e) => {
    if (!e.target.closest('.search-wrapper')) {
      closeDropdown();
    }
  });
};

// ---- Search Input Handler ----
const onSearchInput = () => {
  const query = searchInput.value.trim();
  searchClear.classList.toggle('visible', query.length > 0);
  activeIndex = -1;

  if (query.length === 0) {
    closeDropdown();
    return;
  }

  const filtered = filterCountries(query);
  renderDropdown(filtered, query);
};

// ---- Focus Handler ----
const onSearchFocus = () => {
  const query = searchInput.value.trim();
  if (query.length > 0) {
    const filtered = filterCountries(query);
    renderDropdown(filtered, query);
  }
};

// ---- Keyboard Navigation ----
const onSearchKeydown = (e) => {
  if (!dropdownOpen) return;

  const items = dropdown.querySelectorAll('.dropdown-item');
  if (!items.length) return;

  if (e.key === 'ArrowDown') {
    e.preventDefault();
    activeIndex = Math.min(activeIndex + 1, items.length - 1);
    updateActiveItem(items);
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    activeIndex = Math.max(activeIndex - 1, 0);
    updateActiveItem(items);
  } else if (e.key === 'Enter') {
    e.preventDefault();
    if (activeIndex >= 0 && items[activeIndex]) {
      items[activeIndex].click();
    }
  } else if (e.key === 'Escape') {
    closeDropdown();
    searchInput.blur();
  }
};

// ---- Update Active Dropdown Item ----
const updateActiveItem = (items) => {
  items.forEach((item, i) => {
    item.classList.toggle('active', i === activeIndex);
  });
  if (items[activeIndex]) {
    items[activeIndex].scrollIntoView({ block: 'nearest' });
  }
};

// ---- Filter Countries ----
const filterCountries = (query) => {
  const q = query.toLowerCase();
  return allCountries.filter(c => c.name.toLowerCase().includes(q));
};

// ---- Highlight Match ----
const highlightMatch = (text, query) => {
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return text;
  const before = text.slice(0, idx);
  const match = text.slice(idx, idx + query.length);
  const after = text.slice(idx + query.length);
  return `${before}<mark>${match}</mark>${after}`;
};

// ---- Render Dropdown ----
const renderDropdown = (countries, query) => {
  if (countries.length === 0) {
    dropdown.innerHTML = `<div class="dropdown-empty">No countries match "${escapeHtml(query)}"</div>`;
    openDropdown();
    return;
  }

  const maxShow = 80;
  const slice = countries.slice(0, maxShow);

  dropdown.innerHTML = slice.map((c, i) => `
    <div class="dropdown-item" data-index="${i}" data-name="${escapeHtml(c.name)}">
      <span class="country-flag">${c.flag}</span>
      <span class="country-name">${highlightMatch(escapeHtml(c.name), query)}</span>
    </div>
  `).join('');

  dropdown.querySelectorAll('.dropdown-item').forEach(item => {
    item.addEventListener('click', () => {
      const name = item.dataset.name;
      selectCountry(name);
    });
  });

  openDropdown();
};

// ---- Escape HTML ----
const escapeHtml = (str) => {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
};

// ---- Open / Close Dropdown ----
const openDropdown = () => {
  dropdown.classList.add('open');
  dropdownOpen = true;
};

const closeDropdown = () => {
  dropdown.classList.remove('open');
  dropdownOpen = false;
  activeIndex = -1;
};

// ---- Clear Search ----
const onClearSearch = () => {
  searchInput.value = '';
  searchClear.classList.remove('visible');
  closeDropdown();
  searchInput.focus();
};

// ---- Select Country ----
const selectCountry = async (name) => {
  searchInput.value = name;
  searchClear.classList.add('visible');
  closeDropdown();
  searchInput.blur();

  showLoading(name);

  // Cancel any previous request
  if (currentAbort) currentAbort.abort();
  currentAbort = new AbortController();

  try {
    const response = await fetch(
      `https://restcountries.com/v3.1/name/${encodeURIComponent(name)}?fullText=true`,
      { signal: currentAbort.signal }
    );
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();

    if (data && data.length > 0) {
      renderCountryDetail(data[0]);
    } else {
      showError(`No details found for "${name}".`);
    }
  } catch (err) {
    if (err.name === 'AbortError') return;
    console.error('Fetch country error:', err);
    showError(`Could not load details for "${name}". Please try again.`, name);
  }
};

// ---- Show Loading ----
const showLoading = (name) => {
  mainContent.innerHTML = `
    <div class="loading-state">
      <div class="spinner"></div>
      <p>Loading ${escapeHtml(name)}…</p>
    </div>
  `;
};

// ---- Show Error ----
const showError = (message, retryName) => {
  mainContent.innerHTML = `
    <div class="error-state">
      <div class="error-icon">⚠️</div>
      <p>${escapeHtml(message)}</p>
      ${retryName ? `<button class="retry-btn" id="retryBtn">Try Again</button>` : ''}
    </div>
  `;
  if (retryName) {
    document.getElementById('retryBtn')?.addEventListener('click', () => selectCountry(retryName));
  }
};

// ---- Format Number ----
const formatNumber = (num) => {
  if (num == null) return 'N/A';
  return num.toLocaleString('en-US');
};

// ---- Render Country Detail ----
const renderCountryDetail = (country) => {
  const flag = country.flags?.svg || country.flags?.png || '';
  const common = country.name?.common || 'Unknown';
  const official = country.name?.official || '';
  const region = country.region || 'N/A';
  const subregion = country.subregion || '';
  const population = formatNumber(country.population);
  const area = country.area ? `${formatNumber(country.area)} km²` : 'N/A';
  const capital = country.capital?.join(', ') || 'N/A';
  const continents = country.continents?.join(', ') || region;
  const timezones = country.timezones?.join(', ') || 'N/A';
  const languages = country.languages ? Object.values(country.languages).join(', ') : 'N/A';
  const currencies = country.currencies
    ? Object.values(country.currencies).map(c => `${c.name} (${c.symbol || ''})`).join(', ')
    : 'N/A';
  const callingCodes = country.idd
    ? `${country.idd.root || ''}${(country.idd.suffixes || []).slice(0, 3).join(', ')}`
    : 'N/A';
  const tld = country.tld?.join(', ') || 'N/A';
  const drivingSide = country.car?.side || 'N/A';
  const independent = country.independent != null ? (country.independent ? 'Yes' : 'No') : 'N/A';
  const unMember = country.unMember != null ? (country.unMember ? 'Yes' : 'No') : 'N/A';
  const startOfWeek = country.startOfWeek || 'N/A';
  const mapsUrl = country.maps?.googleMaps || '#';
  const coatOfArms = country.coatOfArms?.svg || country.coatOfArms?.png || '';

  let html = `<div class="country-detail">`;

  // Hero Card
  html += `
    <div class="country-hero">
      <img class="country-flag-large" src="${flag}" alt="Flag of ${escapeHtml(common)}" />
      <div class="country-hero-info">
        <h2>${escapeHtml(common)}</h2>
        ${official !== common ? `<div class="official-name">${escapeHtml(official)}</div>` : ''}
        <span class="region-badge">📍 ${escapeHtml(region)}${subregion ? ` · ${escapeHtml(subregion)}` : ''}</span>
      </div>
    </div>
  `;

  // Info Grid
  html += `<div class="info-grid">`;

  const cards = [
    { icon: '🏙️', label: 'Capital', value: capital },
    { icon: '👥', label: 'Population', value: population },
    { icon: '📐', label: 'Area', value: area },
    { icon: '🌐', label: 'Continent', value: continents },
    { icon: '🗣️', label: 'Languages', value: languages },
    { icon: '💰', label: 'Currencies', value: currencies },
    { icon: '📞', label: 'Calling Code', value: callingCodes },
    { icon: '🌐', label: 'Top-Level Domain', value: tld },
    { icon: '🕐', label: 'Timezones', value: timezones },
    { icon: '🚗', label: 'Driving Side', value: drivingSide.charAt(0).toUpperCase() + drivingSide.slice(1) },
    { icon: '🏛️', label: 'Independent', value: independent },
    { icon: '🇺🇳', label: 'UN Member', value: unMember },
    { icon: '📅', label: 'Start of Week', value: startOfWeek.charAt(0).toUpperCase() + startOfWeek.slice(1) },
  ];

  cards.forEach(card => {
    html += `
      <div class="info-card">
        <div class="info-card-icon">${card.icon}</div>
        <div class="info-card-content">
          <div class="info-card-label">${card.label}</div>
          <div class="info-card-value">${escapeHtml(card.value)}</div>
        </div>
      </div>
    `;
  });

  html += `</div>`;

  // Map Link
  if (mapsUrl !== '#') {
    html += `
      <a class="map-card" href="${mapsUrl}" target="_blank" rel="noopener noreferrer">
        <div class="map-card-icon">🗺️</div>
        <div class="map-card-text">
          <div class="map-label">View on Google Maps</div>
          <div class="map-sublabel">Open ${escapeHtml(common)} in a new tab</div>
        </div>
        <span class="map-card-arrow">→</span>
      </a>
    `;
  }

  // Coat of Arms
  if (coatOfArms) {
    html += `
      <div class="coat-of-arms-section">
        <h3>Coat of Arms</h3>
        <img class="coat-of-arms-img" src="${coatOfArms}" alt="Coat of Arms of ${escapeHtml(common)}" />
      </div>
    `;
  }

  html += `</div>`;
  mainContent.innerHTML = html;
  mainContent.scrollTop = 0;
};

// ---- Initialize ----
boot();
